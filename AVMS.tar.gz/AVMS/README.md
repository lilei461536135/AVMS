### 如何编写测试脚本  
    1.每一个用例都由一个以用例名命名的python脚本作为执行测试的脚本。
      该脚本的主体函数要有返回值，返回值为0或者1，返回值为0，表明测试正常执行完成，返回值为1，表明测试执行异常或者已经判断出测试fail  
    2.每一个用例都由一个以"parse_"+用例名命名的python脚本作为执行完测试之后解析日志得到tc_result json体的脚本  
    3.某个用例执行完之后该用例的所有日志存放在以/用例类型/用例名命名的目录下，例如${log_dir_prefix}/Stress/Stress_CPU_stress/路径  
    eg:
        用例脚本编写示例： https://code.aliyun.com/avms/AVMS_script/blob/Dev/oldScript/demo_stream.py     注意相关日志生成的目录。目录必须按照说明生成在相应的目录下面，文件名字必须按照要求生成指定的文件名。
        parser脚本编写示例： https://code.aliyun.com/avms/AVMS_script/blob/Dev/oldScript/demo_parser.py    脚本输出的json的格式必须按照要求返回。parser脚本请放在工程的parse文件夹下面。
        
### 库函数
为了方便脚本编写，Ali会提供一定的库函数。  
具体库函数请参考[库函数使用说明](https://code.aliyun.com/avms/AVMS_script/blob/Dev/Lib/README.md)  

### 其他相关注意事项
##### 1.测试相关日志存放路径  
**AVMS系统约定所有脚本的日志最终必须放在一个指定的路径下面。**  
指定路径需要从/tmp/tools/name文件里面去获取。此文件只有一行文本，文本内容及为日志存放路径。

```
eg:
    /tmp/tools/name一般内容为/tmp/sshdeploy_speccpu_51_2_2016-04-22-23:39:56/10.52.11.189.
    
    /tmp/sshdeploy_speccpu_51_2_2016-04-22-23:39:56/10.52.11.189
                                                        \performance
                                                        \stress
                                                        \function
                                                            \Func_BIOS
                                                                \Func_BIOS_version（用例名称）
                                                                    \具体用例日志
                                                            \Func_BMC
```

#### 2.hwinfo使用说明

```
    在测试开始之前，avms系统会安装好相应的hwinfo软件包。使用者只需要执行：
    python /tmp/tools/hwinfo/hwinfo.py -pt all 就可以得到hwinfo的输出。
```