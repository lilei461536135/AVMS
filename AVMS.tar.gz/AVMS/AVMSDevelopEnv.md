## AVMS测试环境搭建
AVMS测试环境搭建很简单，运行Lab_env_1.0这个flow就可以搭建相关的测试环境。

Lab_env_1.0的相关作用
```
workflow:
  description: Lab_env_1.0
  name: Lab_env_1.0
  process:
  - action:    ###此action是将AVMS平台里面的avms项目copy到目标机器的/u01/fstack/projects文件夹下面去
      input:
        commit_id: null
        host: ${ip}
        location: /u01/fstack/projects
        namespace: fstack
        password: ${password}
        port: ${port}
        project: avms
        username: ${username}
      name: fstack.sshdeploy
    description: sshdelpoy
    name: sshdelpoy
  - action:     ###此action会下载FTP服务器有关AVMS的测试用例，并且会生成所有脚本都会依赖的/tmp/tools/name文件
      input:    
        cmd: python /u01/fstack/projects/fstack/<% $.task_id %>/avms/downloadFtp.py  ${test_name}
          ${ftpIp}
        host: ${ip}
        log: false
        password: ${password}
        port: ${port}
        timeout: 172800
        username: ${username}
      name: fstack.ssh
    description: down_load
    name: down_load
    on_fail: fstack.aliyun.email content="AVMS down_load error" address=${toAddress}
      title="AVMS down_load error"
  - action:    ###此action为收集系统的相关信息，这一步不是环境部署的必要action
      input:
        cmd: python /u01/fstack/projects/fstack/<% $.task_id %>/avms/python/allinfo.py
          before <% $.task_id %>
        host: ${ip}
        log: false
        password: ${password}
        port: ${port}
        timeout: 172800
        username: ${username}
      name: fstack.ssh
    description: allinfo
    name: allinfo
    on_fail: fstack.aliyun.email content="AVMS allinfo error" address=${toAddress}
      title="AVMS allinfo error"
  share: public
```
由于hwinfo需要依赖相关的软件包，需要运行如下脚本：
/u01/fstack XXX avms/python/config_check/Config_check.py
如果相关测试人员连接外网受限制，可以根据上面的每一步action所做的内容，手动生成相关的文件，即可以搭建相关的测试环境。