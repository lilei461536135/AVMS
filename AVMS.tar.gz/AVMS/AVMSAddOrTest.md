## AVMS平台用例集成和测试

```
在集成到AVMS平台之前，必须能在本地的测试环境下，手动测试通过相关测试用例。
```

### 简单用例（单台机器）
简单用例是指在单台机器上面可以完成的测试项目。测试项目在本地测试通过之后，进行AVMS平台框架测试。
AVMS上面提交测试必须编写相关测试的flow。
#### 编写FLOW

> * 登录AVMS平台页面，点击 工作流管理 -> 模板（Workflow） -> Yaml创建模板（删除掉里面的demo示例）
> * 在Yaml代码框里面编写相关flow信息

```
workflow:
  description: demo_test
  name: demo_test
  process:
  - action:
      input:
        commit_id: null
        host: ${ip}
        location: /u01/fstack/projects
        namespace: fstack
        password: ${password}
        port: ${port}
        project: avms
        username: ${username}
      name: fstack.sshdeploy
    description: sshdelpoy
    name: sshdelpoy
  - action:
      input:
        cmd: python /u01/fstack/projects/fstack/<% $.task_id %>/avms/downloadFtp.py  ${test_name}
          ${ftpIp}
        host: ${ip}
        log: false
        password: ${password}
        port: ${port}
        timeout: 172800
        username: ${username}
      name: fstack.ssh
    description: down_load
    name: down_load
    on_fail: fstack.aliyun.email content="AVMS down_load error" address=${toAddress}
      title="AVMS down_load error"
  - action:
      input:
        cmd: python /u01/fstack/projects/fstack/<% $.task_id %>/avms/uplogToOss.py
          --task_id <% $.task_id %>
        host: ${ip}
        log: false
        password: ${password}
        port: ${port}
        timeout: 172800
        username: ${username}
      name: fstack.ssh
    description: uplogToOss
    name: uplogToOss
    on_fail: fstack.aliyun.email content="AVMS uplogToOss error" address=${toAddress}
      title="AVMS uplogToOss error"
  share: public
```

##### Deploy类型的action
上面的代码里面包含三个基本的action，可以看出第一个action：
```
  - action:
      input:
        commit_id: null
        host: ${ip}
        location: /u01/fstack/projects
        namespace: fstack
        password: ${password}
        port: ${port}
        project: avms
        username: ${username}
      name: fstack.sshdeploy
    description: sshdelpoy
    name: sshdelpoy
    从上面的name：fstack.sshdeploy中可以看到，此action为deploy AVMS项目的相关工程到目标机器上面。
    具体做的动作是：把AVMS平台项目里面的avms（project：avms）项目分发到目标机器的/u01/fstack/projects文件夹下面。
```

##### SSH类型的action
```
  - action:
      input:
        cmd: python /u01/fstack/projects/fstack/<% $.task_id %>/avms/downloadFtp.py  ${test_name}
          ${ftpIp}
        host: ${ip}
        log: false
        password: ${password}
        port: ${port}
        timeout: 172800
        username: ${username}
      name: fstack.ssh
    description: down_load
    name: down_load
    on_fail: fstack.aliyun.email content="AVMS down_load error" address=${toAddress}
      title="AVMS down_load error"
      
    从name:fstack.ssh 中可以看出。此action是通过ssh的方式来在目标机器上面运行相关的命令。
    cmd：python /u01/fstack/projects/fstack/<% $.task_id %>/avms/downloadFtp.py  ${test_name} ${ftpIp}   从这里可以看出来，在目标机器上面运行的是上面的这条命令。
    ${test_name} 和 ${ftpIp}为脚本的参数，test_name 和 ftpIp会在提交任务的时候出现在填写的参数列表里面。用户在提交任务之后AVMS平台会自动替换相关的参数。
```

#### 关于脚本参数的传递
AVMS平台是通过${XXX}这种方式来识别相关参数变量的。XXX为变量名称，在提交此flow的action时，会显示在参数列表里面，以供用户填写相关参数。

eg:
    定义脚本参数
    ![定义脚本参数](http://0571-avms.oss-cn-hangzhou.aliyuncs.com/md_static/define_flow.png)
    提交任务显示
    ![任务显示](http://0571-avms.oss-cn-hangzhou.aliyuncs.com/md_static/flow.png)
    
### 复杂用例（多台机器）
    比较复杂的测试用例可能会涉及到多个action，此时编辑按照上面讲解的action，可以编辑多个action即可。涉及到IP地址不同的，可以修改相关IP的名称，比如qperf_server_ip,qperf_client_ip即可。