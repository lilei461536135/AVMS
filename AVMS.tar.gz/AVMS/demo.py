from Lib.io.io_monitor import io_monitor
import time
from Lib.DataStatistics import DataStaticstic
from Lib.AVMSLogger import AVMSLogger


if __name__ == "__main__":
    avmsLogger = AVMSLogger("INFO")
    avmsLogger.error("demo Test")
    avmsLogger.debug("demo Test")
    avmsLogger.info("demo Test")

    demo_oj = io_monitor("/home/psl/AVMS_script/Lib/cpu", "demo", 1, "/dev/sda")
    demo_oj.start()
    time.sleep(120)
    demo_oj.stop()
    demo_oj.process()

    avmsLogger.info("demo Test")
    ds = DataStaticstic("/home/psl/AVMS_script/Lib/cpu/sda_Wiops", 0, 20, 10)
    data = ds.Staticstic()
    print  data



