import subprocess
from Lib.monitor import monitor
import time
import sys
import commands
import os

def start_monitor(interval_time, path):
    cmd_power = "ipmitool -b 0x6 -t 0x2c raw 0x2e 0xc8 0x57 0x01 0x00 0x01 0x1 0x0 |/usr/bin/xargs|awk '{print strtonum(\"0x\"$5$4)}'"
    cmd_tmp = "ipmitool  -b 0x6 -t 0x2c raw 0x2e 0x4b 0x57 0x01 0x00 0x03 0xff 0xff 0xff 0xff 0x00 0x00 0x00 0x00 | /usr/bin/xargs | awk '{print strtonum(\"0x\"$4)}'"
    cmd_util = "top -b -n 2 | grep Cpu | sed -n '2p' | awk '{print $2}' | tr -d \"%us,\""

    power_fp = open(path + "/cpu_power_tmp", "w")
    tmp_fp = open(path + "/cpu_tmp_tmp", "w")
    util_fp = open(path + "/cpu_util_tmp", "w")

    while True:
        time.sleep(interval_time)
        power = os.popen(cmd_power).read()
        tmp = os.popen(cmd_tmp).read()
        util = os.popen(cmd_util).read()
        power_fp.write(power)
        tmp_fp.write(tmp)
        util_fp.write(util)

        power_fp.flush()
        tmp_fp.flush()
        util_fp.flush()




class cpu_monitor(monitor):

    def __init__(self, log_path, interval_time):
        super(cpu_monitor, self).__init__("cpu_monitor", log_path, None)
        #self.dev_name = dev_name
        self.interval_time = interval_time

    def start(self):
        '''pid = os.fork()
        if pid == 0 :
            start_monitor(self.interval_time, self.log_path)
        else :
            self.monitor_pid.append(pid)'''
        now_path = os.path.dirname(os.path.abspath(__file__))
        fp = open(self.log_path +  '/cpu_turbostat', "w")
        os.system('chmod 777 ' + now_path + '/turbostat')
        child = subprocess.Popen(['nohup', now_path + '/turbostat', '--interval', str(self.interval_time)], stdout=fp)
        print child.pid
        self.monitor_pid.append(child.pid)

    def process(self):
        #fp = open(self.log_path + '/cpu_turbostat', "r")
        cmd = "awk '{if(NF == 16){ print $0} }' " + self.log_path + '/cpu_turbostat > ' + self.log_path + "/cpu_turbostat_tmp"
        (status, output) = commands.getstatusoutput(cmd)
        if status == 0:
            print cmd + " is ok."
        else:
            print cmd + " is error."
            sys.exit(-1)
        fp = open(self.log_path + '/cpu_turbostat_tmp', 'r')

        cpu_json = {}

        cmd = "awk '{if(NF == 16){ print $0} }' " + self.log_path + "/cpu_turbostat_tmp | awk '{print $1}' | grep -o '[0-9]\+' | sort -n | uniq"
        print "cmd:"+ cmd
        (status, output) = commands.getstatusoutput(cmd)
        cpu_num_list = output.split()
        #print cpu_num_list

        #sys.exit(-1)
        for i in cpu_num_list:
            cpu_json[i] = []
            cpu_json[i].append(open(self.log_path + "/" + str(i) + "_cpu_power_tmp", "w"))
            cpu_json[i].append(open(self.log_path + "/" + str(i) + "_cpu_tmp_tmp", "w"))
            cpu_json[i].append(open(self.log_path + "/" + str(i) + "_cpu_util_tmp", "w"))
            cpu_json[i].append(open(self.log_path + "/" + str(i) + "_cpu_fre_tmp", "w"))

        while True:
            line  = fp.readline()
            if not line:
                break
            line_list = line.split()
        #    print line_list
            if line_list[0] == "CPU" or line_list[0] == '-':
                continue
            else :
                '''power_fp.write(line_list[0])
                tmp_fp.write(line_list[0])
                util_fp.write(line_list[0])
                fre_fp.write(line_list[0])'''
                cpu_json[line_list[0]][0].write(line_list[12] + '\n')
                cpu_json[line_list[0]][1].write(line_list[11] + '\n')
                cpu_json[line_list[0]][2].write(line_list[2] + '\n')
                cpu_json[line_list[0]][3].write(line_list[3] + '\n')

                cpu_json[line_list[0]][0].flush()
                cpu_json[line_list[0]][1].flush()
                cpu_json[line_list[0]][2].flush()
                cpu_json[line_list[0]][3].flush()
                '''power_fp.flush()
                tmp_fp.flush()
                util_fp.flush()
                fre_fp.flush()'''


if __name__ == "__main__":
    cpu_oj = cpu_monitor("/u01/fstack/projects/fstack/9721488/public_inspur/cooperation/Lib/cpu", 2)
    cpu_oj.start()
    time.sleep(10)
    cpu_oj.stop()
    cpu_oj.process()