# -*- coding: utf-8 -*-
__author__ = 'maxuhua'

import paramiko
import os
import commands
import time
import re
import time


class Icommand(object):
    def run_remote_cmd(self):
        pass
    def run_local_cmd(self):
        pass

class reboot_command(Icommand):
    def __init__(self,local_cmd, remote_cmd):
        self.local_cmd = local_cmd
        self.remote_cmd = remote_cmd
    def run_remote_cmd(self):
        return self.remote_cmd
    def run_local_cmd(self):
        if self.local_cmd == "":
            return "continue"
        status,output = commands.getstatusoutput(self.local_cmd)
        print output
        return "continue"

class reboot(object):
    def __init__(self,sut_ip,sut_user,sut_passwd,command,count=3,rebootcommand="reboot",port=22):
        self.sut_ip = sut_ip
        self.sut_user = sut_user
        self.sut_passwd = sut_passwd
        self.port = port
        self.count = count
        self.command = command
        self.rebootcommand = rebootcommand
        self.init_ssh()

    def init_ssh(self):
        paramiko.util.log_to_file("/tmp/paramiko.log")
        self.client=paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    def ping(self,ip):
        connect = re.compile(r"(\d) received")
        cmd = "ping -c 3 "+ip
        status,output = commands.getstatusoutput(cmd)
        if status == 0:
            count=re.findall(connect,output)
            if int(count[0]) >0:
                return True
            else:
                return False
        else:
            return False

    """keep ping #count ,if ping success within timeout return True, else return False"""
    def loop_ping(self,ip,count=10,interval=30):
        while count >0:
            if self.ping(ip):
                return True
            time.sleep(interval)
            count=count-1
        return False

    def check_ssh_work(self):
        try:
            self.client.connect(self.sut_ip,self.port,self.sut_user,self.sut_passwd)
            return True
        except:
            return False

    def loop_check_ssh_work(self,count=3,interval=15):
        while count>0:
            if self.check_ssh_work():
                return True
            time.sleep(interval)
            count=count-1
        return False

    def loop_check_restarted(self, rebootTime, count = 10, interval = 30):
        while count > 0:
            try:
                stdin,stdout,stderr = self.client.exec_command("cat /proc/uptime | awk '{print $1}'")
                uptime = stdout.readlines()
                now = time.time()
                if now - float(uptime[0].strip()) > rebootTime:
                    return True
            finally:
                count = count - 1
            time.sleep(interval)
        return False


    def start(self):
        index = 0
        rebootTime = ""
        while index <= self.count:
            if self.loop_ping(self.sut_ip):
                if self.loop_check_ssh_work():
                    if index == 0:
                        self.client.exec_command("echo 0 > /tmp/rebootCount")
                    elif self.loop_check_restarted(rebootTime) == True :
                        self.client.exec_command("echo " + str(index) + " > /tmp/rebootCount")
                    else :
                        return index - 1
                    try:
                        index = index + 1
                        stdin,stdout,stderr = self.client.exec_command(self.command)
                        for line in stdout.readlines():
                            line = line.strip()
                            if re.match("break",line):
                                break
                            elif re.match("continue",line):
                                if index == self.count + 1:
                                    return index - 1
                                rebootTime = time.time()
                                stdin,stdout,stderr = self.client.exec_command(self.rebootcommand)
                                time.sleep(60)
                                continue
                            elif re.match("return -1",line):
                                return -1
                    except:
                        return index - 1

                else:
                    return index - 1
            else:
                return index - 1
        return index - 1


if __name__ == "__main__":
    command = "echo continue"
    reb = reboot("10.137.75.6","root","password",command,3,"ipmitool raw 0 2 3")
    ll = reb.start()
    print ll