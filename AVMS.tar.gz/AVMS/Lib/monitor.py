
import os
import signal

class monitor(object):
    def __init__(self, monitor_name, log_path, log_name):
        self.monitor_pid = []
        self.monitor_name = monitor_name
        self.log_path = log_path
        self.log_name = log_name


    #start some pid
    def start(self):
        pass

    #process some log
    def process(self):
        pass

    #stop some pid
    def stop(self):
        for pid in self.monitor_pid:
            try:
                a = os.kill(pid, signal.SIGKILL)
                print "The thread %s is kill, return code is %s." % (pid, a)
            except OSError, e:
                print "The thread %s may be not exist." % (pid)




