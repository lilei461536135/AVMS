import os
import datetime
import sys

class MessageFileSplit(object):
    def __init__(self, outputFile, dateStr = None ):
        if dateStr == None:
            uptime = os.popen("cat /proc/uptime | awk '{print $1}'").readlines()
            now = datetime.datetime.now().strftime('%s')
            self.startTime = float(now) - float(uptime[0].strip())
        else :
            self.startTime = datetime.datetime.strptime(dateStr, "%Y-%m-%d %H:%M:%S").strftime('%s')
        self.outputFile = outputFile

    def DoSplit(self):
        if str(self.outputFile).lower() == "stdout":
            outFile = None
        else :
            if os.path.exists(self.outputFile):
                os.remove(self.outputFile)
            outFile = open(self.outputFile,"w")

        for line in open("/var/log/messages"):
            strings = line.split()
            if len(strings) == 0:
                continue
            mon = "0"
            if strings[0] == "Jan":
                mon = "01"
            elif strings[0] == "Feb":
                mon = "02"
            elif strings[0] == "Mar":
                mon = "03"
            elif strings[0] == "Apr":
                mon = "04"
            elif strings[0] == "May":
                mon = "05"
            elif strings[0] == "Jun":
                mon = "06"
            elif strings[0] == "Jul":
                mon = "07"
            elif strings[0] == "Aug":
                mon = "08"
            elif strings[0] == "Sep":
                mon = "09"
            elif strings[0] == "Oct":
                mon = "10"
            elif strings[0] == "Nov":
                mon = "11"
            elif strings[0] == "Dec" :
                mon = "12"
            else :
                continue
            year = datetime.datetime.now().year
            day = strings[1]
            time = strings[2]
            dtstr = str(year) + "-" + mon + "-" + day + " " + time
            t2=datetime.datetime.strptime(dtstr, "%Y-%m-%d %H:%M:%S").strftime('%s')
            if float(t2) > float(self.startTime):
                if outFile == None :
                    print line,
                else:
                    outFile.write(line)
        if outFile != None:
            outFile.flush()
            outFile.close()

if __name__ == "__main__" :
    if len(sys.argv) < 1:
        print "Usage: MessageFileSplit outputFile [startTime]"
        print "outputFile  absolute path of the outputFile"
        print "startTime  a string with the datetime format \"%Y-%m-%d %H:%M:%S\""
        print "if  the startTime left blank, the splited message will be logged since the os booted this time by default"
        sys.exit(-1)
    if len(sys.argv) > 1:
        mss = MessageFileSplit(sys.argv[0], sys.argv[1])
    else :
        mss = MessageFileSplit(sys.argv[0])
    mss.DoSplit()

