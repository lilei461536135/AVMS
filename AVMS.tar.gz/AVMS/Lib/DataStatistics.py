import sys
import string

class DataStaticstic(object):
    def __init__(self, dataFile, start, end, step):
        self.dataFile = dataFile
        self.start = start
        self.end = end
        self.step = step

    def Staticstic(self):
        min = 0.0
        max = 0.0
        avg = 0.0
        per90 = 0.0
        per95 = 0.0
        per99 = 0.0
        list = []
        sum = 0.0
        for line in open(self.dataFile):
            try:
                list.append(string.atof(line))
                sum += string.atof(line)
            except:
                continue
        list.sort()
        min = list[0]
        count = len(list)
        max = list[count-1]
        avg = round(sum / count, 2)
        per90 = list[int(count * 0.9 -1)]
        per95 = list[int(count * 0.95 -1)]
        per99 = list[int(count * 0.99 -1)]
        steps = (self.end - self.start)/self.step + 2
        list2 = [0] * steps
        base = self.start
        for x in list:
            if x <= self.start:
                index = 0
            else:
                index = int((x - self.start)/self.step) + 1
                if index >= steps:
                    index = steps - 1
            list2[index] = list2[index] + 1
        tData = {}
        tData["min"] = min
        tData["max"] = max
        tData["avg"] = avg
        tData["90per"] = per90
        tData["95per"] = per95
        tData["99per"] = per99
        for y in range(0, steps):
            if y == 0:
                tData["lt" + str(self.start)] = list2[y]
            elif y == steps - 1:
                tData["gt" + str(self.end)] = list2[y]
            else :
                tData[str(self.start + self.step * (y - 1)) + "~" + str(self.start + self.step * y)] = list2[y]
        return tData

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print "Usage: DataStaticstic dataFile start end step"
        sys.exit(-1)
    ds=DataStaticstic(sys.argv[0],sys.argv[1],sys.argv[2],sys.argv[3])
    ds.Staticstic()