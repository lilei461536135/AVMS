import json

class Base_line():
    def __init__(self, path = "/home/psl/AVMS_script/Lib/base_line/base.json"):
        with open(path) as fp:
            self.base_line = json.load(fp)

    def get_baseline(self, key1, key2):
        try:
            number = self.base_line[key1][key2]
        except:
            number = None
        return number

if __name__ == "__main__":
    obj = Base_line("/home/psl/AVMS_script/Lib/base_line/base.json")
    print obj.base_line
    print obj.get_baseline("cpu", "powe")