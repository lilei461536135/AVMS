from Lib.monitor import monitor
import time
import os
import re

def start_monitor(interval_time, path):
    cmd_sdr = "ipmitool sdr"

    #pow_fp = open(path + "/mem_power_tmp", "w")
    fp_dict = {}
    sdr_content = os.popen(cmd_sdr).read()
    sdr_list = sdr_content.split('\n')

    for item in sdr_list:
        tmp = re.search(r"FAN\w*", item)
        if tmp != None:
            name = tmp.group()
            print name
            if name not in fp_dict.keys():
                fp = open(path + "/" + name, "w")
                fp_dict[name] = fp
                continue

        tmp = re.search(r"SYS_12V", item)
        if tmp != None:
            name = tmp.group()
            print name
            if name not in fp_dict.keys():
                fp = open(path + "/" + name, "w")
                fp_dict[name] = fp
                continue

        tmp = re.search(r"Inlet_Temp", item)
        if tmp != None:
            name = tmp.group()
            print name
            if name not in fp_dict.keys():
                fp = open(path + "/" + name, "w")
                fp_dict[name] = fp
                continue

    while True:
        time.sleep(interval_time)
        sdr_content = os.popen(cmd_sdr).read()
        sdr_list = sdr_content.split('\n')
        keys = fp_dict.keys()
        for item_key in keys:
            for content in sdr_list:
                if item_key in content:
                    print item_key
                    tmp = re.search(r"\s\d+\W*\d+\s", content)
                    if tmp != None:
                        num = tmp.group().strip()
                        print num
                        fp_dict[item_key].write(num + "\n")
                        fp_dict[item_key].flush()


class sdr_monitor(monitor):

    def __init__(self, log_path, interval_time):
        super(sdr_monitor, self).__init__("sdr_monitor", log_path, None)
        #self.dev_name = dev_name
        self.interval_time = interval_time

    def start(self):
        pid = os.fork()
        if pid == 0 :
            start_monitor(self.interval_time, self.log_path)
        else:
            self.monitor_pid.append(pid)


if __name__ == "__main__":
    sdr_oj = sdr_monitor("/home/shaolong.psl/Lib/sdr", 1)
    sdr_oj.start()
    time.sleep(10)
    sdr_oj.stop()
    sdr_oj.process()