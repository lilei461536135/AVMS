import subprocess
from Lib.monitor import monitor
import time
import os

def start_monitor(interval_time, log_path, dev ):
    pass
    cmd = "ip -s link show " + dev

    packets_fp = open(log_path + "/pps_tmp", "w")
    dropped_fp = open(log_path + "/plp_tmp", "w")

    #up_packets = 0
    #up_dropped = 0

    while True:
        time.sleep(interval_time)
        '''power = os.popen(cmd_power).read()
        power_fp.write(power)
        power_fp.flush()'''
        log_net = os.popen(cmd).read()
        log_list = log_net.split('\n')
        packets = int(log_list[3].split()[1]) + int(log_list[5].split()[1])
        dropped = int(log_list[3].split()[3]) + int(log_list[5].split()[3])

        dropped_fp.write(str(dropped) + '\n')
        packets_fp.write(str(packets) + '\n')

        dropped_fp.flush()
        packets_fp.flush()

        '''if up_packets == 0:
            packets = int(log_list[3].split()[1]) + int(log_list[5].split()[1])
            up_packets = packets
            dropped = int(log_list[3].split()[3]) + int(log_list[5].split()[3])
            up_dropped = dropped
            continue
        else:
            packets = int(log_list[3].split()[1]) + int(log_list[5].split()[1])
            dropped = int(log_list[3].split()[3]) + int(log_list[5].split()[3])
            pps = packets - up_packets'''





class net_monitor(monitor):

    def __init__(self, log_path, log_name, interval_time, dev):#, dev_name):
        super(net_monitor, self).__init__("net_monitor", log_path, log_name)
        #self.dev_name = dev_name
        self.interval_time = interval_time
        self.dev = dev

    def start(self):
        fp = open(self.log_path +  '/' + self.log_name, "w")
        child = subprocess.Popen(['nohup', 'dstat', '-n', '--nocolor', '-N', self.dev ,str(self.interval_time)], stdout=fp)
        print child.pid
        self.monitor_pid.append(child.pid)

        pid = os.fork()
        if pid == 0 :
            start_monitor(self.interval_time, self.log_path, self.dev)
        else :
            self.monitor_pid.append(pid)


    def process(self):
        pass
        log_path = self.log_path + '/' + self.log_name
        fp_process = open(log_path, "r")
        i = 0
        fp_bw_send = open(self.log_path + "/bw_send_tmp", "w")
        fp_bw_recv = open(self.log_path + "/bw_recv_tmp", "w")
        while True:
            line  = fp_process.readline()
            i = i + 1
            if not line:
                break

            if i <= 2 :
                continue
            else:
                #print line
                line_list = line.split()
                if line_list[1][-1] == 'B':
                    fp_bw_send.write(line_list[1][0:-1] + "\n")
                elif line_list[1][-1] == "K":
                    fp_bw_send.write((str((int)(line_list[1][0:-1])*1024)) + "\n")
                elif line_list[1][-1] == "M":
                    fp_bw_send.write((str((int)(line_list[1][0:-1])*1048576)) + "\n")
                elif line_list[1][-1] == "G":
                    fp_bw_send.write((str((int)(line_list[1][0:-1])*1073741824)) + "\n")
                else:
                    fp_bw_send.write(line_list[1] + "\n")

                if line_list[0][-1] == 'B':
                    fp_bw_recv.write(line_list[0][0:-1] + "\n")
                elif line_list[1][-1] == "K":
                    fp_bw_recv.write((str((int)(line_list[0][0:-1])*1024)) + "\n")
                elif line_list[1][-1] == "M":
                    fp_bw_recv.write((str((int)(line_list[0][0:-1])*1048576)) + "\n")
                elif line_list[1][-1] == "G":
                    fp_bw_recv.write((str((int)(line_list[0][0:-1])*1073741824)) + "\n")
                else:
                    fp_bw_recv.write(line_list[0] + "\n")


                #fp_bw_send.write(line_list[1] + "\n")
                #fp_bw_recv.write(line_list[0] + "\n")
        fp_bw_send.close()
        fp_bw_recv.close()




if __name__ == "__main__":
    net_oj = net_monitor("/home/psl/AVMS_script/Lib/cpu", "net_name1", 5, "eth1")#, "eth0")
    net_oj.start()
    time.sleep(10)
    net_oj.stop()
    net_oj.process()