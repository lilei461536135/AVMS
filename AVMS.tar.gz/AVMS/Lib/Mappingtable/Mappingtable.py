# -*- coding: utf-8 -*-
import os
import re
import json

class Mappingtable():
    def __init__(self, mpt_black_path, mpt_while_path):
        self.mappingtable_white = mapping_table(mpt_while_path).get_mpl_re()
        self.mappingtable_black = mapping_table(mpt_black_path).get_mpl_re()


class mapping_table(object):
    def __init__(self,filename):
        self.filename =filename
        self.mapping_table,self.mapping_table_re=self.build()


    def build(self):
        with open(self.filename) as f:
            mapping_table=json.load(f)
        mapping_table_re={}
        for key in mapping_table.keys():
            mapping_table_re[key]=re.compile(mapping_table[key])
        return mapping_table,mapping_table_re
    def get_mpl(self):
        return self.mapping_table
    def get_mpl_re(self):
        return self.mapping_table_re

if __name__ == "__main__":
    obj = Mappingtable("/home/psl/AVMS_script/Lib/Mappingtable/Mappingtable_black", "/home/psl/AVMS_script/Lib/Mappingtable/Mappingtable_white")
    print obj.mappingtable_black
    print obj.mappingtable_white