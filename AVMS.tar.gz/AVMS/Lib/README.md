# AVMS相关API使用说明
## 监控API

> * [CPU监控](https://code.aliyun.com/avms/AVMS_script/tree/Dev/Lib#cpu%E7%9B%91%E6%8E%A7)
> * [IO监控](https://code.aliyun.com/avms/AVMS_script/tree/Dev/Lib#io%E7%9B%91%E6%8E%A7)
> * [MEM监控](https://code.aliyun.com/avms/AVMS_script/tree/Dev/Lib#mem%E7%9B%91%E6%8E%A7)
> * [NET监控](https://code.aliyun.com/avms/AVMS_script/tree/Dev/Lib#net%E7%9B%91%E6%8E%A7)
> * [整机功耗监控](https://code.aliyun.com/avms/AVMS_script/tree/Dev/Lib#%E6%95%B4%E6%9C%BA%E5%8A%9F%E8%80%97%E7%9B%91%E6%8E%A7)

### CPU监控
AVMS CPU监控可以帮助用户监控CPU的频率、温度、功耗、利用率。
具体用方法非常简单：

    from Lib.cpu.cpu_monitor import cpu_monitor
    import time
    
    cpu_oj = cpu_monitor("/home/shaolong.psl/Lib/cpu", 5)   ##  第一个参数是日志存放路径，请确保相关路径存在。第二个参数是采样间隔时间，建议采用10S。
    cpu_oj.start()  ##此函数为开始cpu的监控
    #time.sleep(10)
    cpu_oj.stop()   ##  这里停止CPU的监控
    cpu_oj.process()   ##这里开始处理监控CPU的原始日志。
process函数会产生很多标准的日志文件，文件名称也是相对固定的。
如果只有一颗CPU相关日志文件的名称会如下：

    0_cpu_util_tmp
    0_cpu_tmp_tmp
    0_cpu_power_tmp
    0_cpu_fre_tmp
    
如果有多个CPU，只需要把前面的数字改变一下即可以得到相应CPU的监控数据
监控文件里面的数据是按照行来分割的
    
    0_cpu_util_tmp:
                0.22
                0.09
                0.17
                0.18
                0.05
                0.27

### IO监控
AVMS IO监控可以帮助用户监控IO的iops、bw、lat、利用率。
具体使用方法：
    
    from Lib.io.io_monitor import io_monitor
    import time
    
    io_oj = io_monitor("/home/psl/AVMS_script/Lib/cpu", "IO_iostat", 2, "/dev/sda")
    #第一个参数是监控原始日志存放路径,路径必须存在
    #第二个参数是监控原始日志的名称
    #第三个参数为采样间隔
    #第四个参数是需要监控的盘符，如果有多个盘符用逗号分割开
    io_oj.start()   #开始监控测试
    #time.sleep(30)
    io_oj.stop()    #结束监控
    io_oj.process() #处理IO监控的原始日志，生成规整的日志

process函数会产生很多标准的日志文件，文件名称也是相对固定的。
如果只有sda会产生下面的日志。如果有多块盘，只需修改前面的盘符即可。

    sda_await
    sda_Rbw
    sda_Wbw
    sda_Riops
    sda_Wiops
    sda_util
    
### MEM监控
AVMS MEM监控可以帮助用户监控内存的功耗、频率和使用率
具体使用方法：
    
    from Lib.mem.mem_monitor import mem_monitor
    import time
    
    mem_oj = mem_monitor("/home/shaolong.psl/Lib/cpu", 1)
    ###第一个参数是原始日志参数路径
    ###第二个参数是日志采集间隔时间
    mem_oj.start()      ###开始采集日志
    #time.sleep(10)
    mem_oj.stop()       ###停止采集日志
    mem_oj.process()    ###处理原始日志
    
process函数会产生很多标准的日志文件，文件名称也是相对固定的。
mem监控日志处理完成后会生成如下文件

    mem_util_tmp
    mem_power_tmp
    mem_fre_tmp
    
### NET监控
AVMS NET监控可以帮助用户监控网络的带宽、pps、丢包率
具体使用方法：

    from Lib.net.net_monitor import net_monitor
    net_oj = net_monitor("/home/psl/AVMS_script/Lib/cpu", "net_dstat", 5, "eth1")
    ###第一个参数是原始日志参数路径
    ###第二个参数是原始日志的名称
    net_oj.start()          ###开始网络监控
    #time.sleep(10)
    net_oj.stop()           ###停止网络监控
    net_oj.process()        ###处理网络监控原始日志
    
process函数会产生很多标准的日志文件，文件名称也是相对固定的。
net监控日志处理完成后会生成如下文件

    pps_tmp
    plp_tmp
    bw_send_tmp
    bw_recv_tmp
    
### 整机功耗监控
AVMS 整机功耗监控可以帮助用户监控节点的整机功耗。
具体使用方法：
    
    
    from Lib.server_power.server_power import server_monitor
    server_oj = server_monitor("/home/psl/AVMS_script/Lib/cpu", 5)
    server_oj.start()
    #time.sleep(30)
    server_oj.stop()
    
## 日志API
提供简单的方法将要记录日志的地方按照一定的规则记录到日志中，具体使用方法：

    #其中，构造函数中的参数为“debug”，“info”，“warning”和“error”，默认为“info”
    #debug < info < warning < error
    avmsLogger = AVMSLogger("info")
    avmsLogger.error("this is a error msg")
    avmsLogger.info("this is a info msg")
    avmsLogger.warning("this is a warning msg")
    avmsLogger.debug("this is a debug msg")

以上代码在日志中的打印结果为：

    [2016-Aug-01 19:42:22][log_test.py] [ERROR  ] this is a error msg
    [2016-Aug-01 19:42:22][log_test.py] [INFO   ] this is a info msg
    [2016-Aug-01 19:42:22][log_test.py] [WARNING] this is a warning msg

由于定义的日志级别为info界别，因此debug日志并没有在日志中打印

## 数据统计API
提供简单的方法将一系列数据进行统计，并呈现出来，具体使用方法：

    #构造函数有4个参数，其中第一个参数为原始数据的路径，要求原始数据文件中每一行为一条数据
    #第二个参数为要进行统计的范围的最小值，第三个参数为要进行统计的范围的最大值，第四个参数为要进行统计的范围中的间隔
    ds = DataStaticstic("/home/psl/AVMS_script/Lib/cpu/sda_Wiops", 12, 18, 2)
    tData = ds.Staticstic()
    print tData

以上示例代码的输出为：

    {
        "12~14": 19876, 
        "90per": 19.0, 
        "95per": 19.5, 
        "min": 10.0, 
        "max": 20.0, 
        "gt18": 20100, 
        "16~18": 19884, 
        "99per": 19.9, 
        "14~16": 19884, 
        "lt12": 20256, 
        "avg": 14.99
    }
    
其中返回体tData是一个json对象，在实际代码中，请参考json的处理方法

## 系统message文件获取特定时间之后的日志API
提供简单的API实现对系统message中获取得到指定时间之后的内容，并保存到文件中。具体使用方法：

    #MessageFileSplit类的构造函数中，第一个参数为一个绝对路径，用于将获取到的日志输出到该文件中
    #也可以指定为stdout，则打印到标准输出
    #第二个参数为一个%Y-%m-%d %H:%M:%S格式的时间字符串，用于指定需要获取该时间点之后的Message内容
    #如果第二个参数指定为空，则获取本次系统启动之后的所有messgae内容
    mss = MessageFileSplit("/tmp/tmpMessage.log", "07-26-2016 16:13:09")
    mss.DoSplit()

上述代码没有输出，只是将获取的内容存储到指定的文件中

## 重启API
对于有些特定的用例，需要对SUT进行重启，这种用例需要用到reboot类。当前采用的方式是通过另外一台设备来控制SUT进行重启，并指定重启后在SUT上执行某个命令或者脚本。  
具体使用方法如下：
    
    #reboot类的实例化必须要有5个参数，依次表示SUT的IP地址，登录SUT的用户名，登录SUT的密码，需要在SUT上执行的命令，重启的次数
    #如果不是重启，而是power cycle或者power reset，还需要指定相应的命令。其中power cycle的命令为“ipmitool raw 0 2 2”, power reset的命令为“ipmitool raw 0 2 3”
    #如果ssh默认端口不是22，还可以额外进行ssh端口的指定
    #如下范例中，额外指定了重启命令为power reset，指定了ssh端口为3001
    command = "/usr/bin/python /tmp/tool/Stress_AliFlash_Firmware_Update.py"
    reb = reboot("10.137.75.6","root","password",command,100,"ipmitool raw 0 2 3",3001)
    count = reb.start()
    if  count == 100
        return 0
    else
        return 1
    #其中start函数的返回值为正确执行重启的次数。正确重启的次数通过command命令或脚本的返回值进行判定。
    #command命令或者脚本需要将返回值打印为stdout，只能为break，continue或者return -1。
    #三个返回值分别代表：
    #break表明该次重启之后发现错误，例如检测到的hwinfo和基准版本不匹配，用例要求测试用例失败，无需指定后续的重启测试
    #continue表明该次重启之后所有检测正常，可以执行下一次重启
    #return -1暂时保留，表明该次重启发生无法预知的错误，本测试用例执行可能无效等等

对于重启API，SUT上进行检测的脚本比较重要，例如用例[Stress_AliFlash_Firmware_Update](https://code.aliyun.com/avms/AVMS_script/issues/182)，重启后需要对比hwinfo，且需要收集检查日志，因此在SUT上的脚本伪代码可能为：
    
    if (cat /tmp/rebootCount) == 0                          #系统中记录重启次数的文件
        hwinfo > hwinfo.base                                #第0次重启，将当前的hwinfo作为base
    else
        hwinfo > $(cat /tmp/rebootCount)/hwinfo.log         #获取第N次重启的硬件信息
        getSysLog > $(cat /tmp/rebootCount)/sysLog.log      #获取第N次重启的系统日志，并保存在该重启次数的路径下
        if compare(hwinfo.base, hwinfo.log)
            echo continue                                   #如果第N次重启的hwinfo和base一致，则继续做下一次重启测试
        else
            echo break                                      #如果第N次重启的hwinfo和base不同，则测试失败