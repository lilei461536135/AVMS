import logging

class AVMSLogger(object):
    def __init__(self, level):
        try:
            file = open("/tmp/tools/name")
            self.fileName = file.readline().strip().strip('\n') + "/avms.log"
            file.close()
        except:
            self.fileName = "/tmp/avms.log"
        self.level = str(level).lower()
        if  self.level == "debug" :
            self.level = logging.DEBUG
        elif self.level == "info" :
            self.level = logging.INFO
        elif self.level == "warning" :
            self.level = logging.WARNING
        elif self.level == "error" :
            self.level = logging.ERROR
        else :
            self.level = logging.INFO
        self.format = "[%(asctime)s][%(filename)s][%(levelname)-7s]:%(message)s"
        self.dateFormat = "%Y-%b-%d %H:%M:%S"
        logging.basicConfig(level=self.level,format=self.format,datefmt=self.dateFormat,filename=self.fileName,filemode='a')

    def debug(self,message):
        logging.debug(message)

    def info(self,message):
        logging.info(message)

    def warning(self,message):
        logging.warning(message)

    def error(self,message):
        logging.error(message)

if __name__ == "__main__":
    avmsLogger = AVMSLogger("WARNING")
    avmsLogger.error("this is an error msg")
    avmsLogger.debug("this is a debug msg")