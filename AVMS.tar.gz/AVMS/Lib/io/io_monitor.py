import subprocess
from Lib.monitor import monitor
import time


class io_monitor(monitor):

    def __init__(self, log_path, log_name, interval_time, dev_name="ALL"):
        super(io_monitor, self).__init__("io_monitor", log_path, log_name)
        self.dev_name = dev_name
        self.interval_time = interval_time

    def start(self):
        fp = open(self.log_path +  '/' + self.log_name, "w")
        child = subprocess.Popen(['nohup', 'iostat', '-xk', str(self.interval_time), '-p', self.dev_name], stdout=fp)
        print child.pid
        self.monitor_pid.append(child.pid)

    def process(self):
        log_path = self.log_path + "/" +self.log_name
        fp = open(log_path, 'r')
        stat_json = {}
        metrics_list = ["Riops", "Wiops", "Rbw", "Wbw", "await", "util"]
        flag = 1
        flag_1 = 0
        while True:
            line  = fp.readline()
            if not line :
                fp.close()
                break
            print line
            '''if self.dev_name != "ALL":
                dev_list = self.dev_name.split(',')
                for item in dev_list:
                    stat_json[item] = []
                    for metric in metrics_list:
                        file_name = self.log_path + '/' + item + "_" + metric
                        fp_tmp = open(file_name,'w')
                        stat_json[item].append(fp_tmp)

                dev_name = line.split()[0]
                line_list = line.split()
                for dev in stat_json.keys():
                    pass
                    if dev_name == dev:
                        stat_json[dev][0].write(line_list[3]+'\n')
                        stat_json[dev][1].write(line_list[4]+'\n')
                        stat_json[dev][2].write(line_list[5]+'\n')
                        stat_json[dev][3].write(line_list[6]+'\n')
                        stat_json[dev][4].write(line_list[9]+'\n')
                        stat_json[dev][5].write(line_list[-1]+'\n')
            else:'''
            #if line[0:6] == "Device" and flag == 1:
            if flag == 1:
                #flag_1 = 0
                if line[0:6] == "Device":
                    flag_1 = 1
                    continue
                else :
                    if len(line) > 5:
                        dev_name = line.split()[0]
                        #stat_json[dev_name] = []
                        if dev_name[-1] >= "0" and dev_name[-1] <= '9' or dev_name[0] == 'L' or dev_name[0:3] == 'avg' or len(dev_name) == 0:
                            continue
                        else :
                            stat_json[dev_name] = []
                            for metric in metrics_list:
                                file_name = self.log_path + '/' + dev_name + "_" + metric
                                fp_tmp = open(file_name,'w')
                                stat_json[dev_name].append(fp_tmp)
                    else:
                        if flag_1 == 1:
                            flag = 0
            else:
                if len(line) < 3 or line[0:6] == "Device" or line[0:2] == "  ":
                    continue
                else:
                    dev_name = line.split()[0]
                    line_list = line.split()
                    for dev in stat_json.keys():
                        pass
                        if dev_name == dev:
                            stat_json[dev][0].write(line_list[3]+'\n')
                            stat_json[dev][1].write(line_list[4]+'\n')
                            stat_json[dev][2].write(line_list[5]+'\n')
                            stat_json[dev][3].write(line_list[6]+'\n')
                            stat_json[dev][4].write(line_list[9]+'\n')
                            stat_json[dev][5].write(line_list[-1]+'\n')

        for dev in stat_json.keys():
            for p in stat_json[dev]:
                try:
                    p.close()
                except :
                    print p , " is close error."






if __name__ == "__main__":
    io_oj = io_monitor("/home/psl/AVMS_script/Lib/cpu", "cpu_name1", 2, "/dev/sda")
    io_oj.start()
    time.sleep(30)
    io_oj.stop()
    io_oj.process()
