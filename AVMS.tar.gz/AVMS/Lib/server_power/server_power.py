import subprocess
from Lib.monitor import monitor
import time
import os


def start_monitor(interval_time, path):
    cmd_power = "ipmitool -t 0x2c -b 6 raw 0x2E 0xC8 0x57 0x01 0x00 0x1 0x0 0x0 |/usr/bin/xargs|awk '{print strtonum(\"0x\"$5$4)}'"

    power_fp = open(path + "/server_power_tmp", "w")

    while True:
        time.sleep(interval_time)
        power = os.popen(cmd_power).read()
        power_fp.write(power)
        power_fp.flush()




class server_monitor(monitor):
    def __init__(self, log_path, interval_time):
        super(server_monitor, self).__init__("server_monitor", log_path, None)
        #self.dev_name = dev_name
        self.interval_time = interval_time

    def start(self):
        pid = os.fork()
        if pid == 0 :
            start_monitor(self.interval_time, self.log_path)
        else :
            self.monitor_pid.append(pid)




if __name__ == "__main__":
    cpu_oj = server_monitor("/home/psl/AVMS_script/Lib/cpu", 5)
    cpu_oj.start()
    time.sleep(30)
    cpu_oj.stop()
