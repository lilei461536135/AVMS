import subprocess
from Lib.monitor import monitor
import time
import sys
import commands
import os

def start_monitor(interval_time, path):
    cmd_power = "ipmitool -b 0x6 -t 0x2c raw 0x2e 0xc8 0x57 0x01 0x00 0x01 0x2 0x0 |/usr/bin/xargs|awk '{print strtonum(\"0x\"$5$4)}'"
    cmd_fre = "dmidecode --type memory | grep -e '^\sSpeed: [0-9]' | uniq"
    cmd_util = "free"

    power_fp = open(path + "/mem_power_tmp", "w")
    fre_fp = open(path + "/mem_fre_tmp", "w")
    util_fp = open(path + "/mem_util_tmp", "w")

    while True:
        time.sleep(interval_time)

        power = os.popen(cmd_power).read()
        fre_tmp = os.popen(cmd_fre).read()
        fre = fre_tmp.split()[1]
        util_tmp = os.popen(cmd_util).read()
        util_list = util_tmp.split("\n")[1].split()
        print "util_list:", util_list
        util = ((float)(util_list[2]) / (float)(util_list[1])) * 100


        power_fp.write(power)
        fre_fp.write(fre + '\n')
        util_fp.write((str)(util) + '\n')

        power_fp.flush()
        fre_fp.flush()
        util_fp.flush()




class mem_monitor(monitor):

    def __init__(self, log_path, interval_time):
        super(mem_monitor, self).__init__("mem_monitor", log_path, None)
        #self.dev_name = dev_name
        self.interval_time = interval_time

    def start(self):
        pid = os.fork()
        if pid == 0 :
            start_monitor(self.interval_time, self.log_path)
        else :
            self.monitor_pid.append(pid)


if __name__ == "__main__":
    cpu_oj = mem_monitor("/home/shaolong.psl/Lib/cpu", 1)
    cpu_oj.start()
    time.sleep(10)
    cpu_oj.stop()
    cpu_oj.process()