import os
import sys
import re
from pymongo import MongoClient
from fstack.utils.baseconfig import base_config
#######
from SpecCPU_INT_base import SpecCPU_INT_base
from server_description import server_description
from SpecCPU_FP_base import SpecCPU_FP_base
from Pi_base import Pi_base
from SpecPower_base import SpecPower_base
from unixbench_base import unixbench_base
from Stream_base import Stream_base
from fio_base import fio_base
from qperf_base import qperf_base
from mlc_base import mlc_base
from mem_bw_base import mem_bw_base
from mem_lat_base import mem_lat_base
#######





class db_base_manager(object):
    def __init__(self,number,sn, user_id, *ip):
        self.number=number
        self.sn=sn
        self.ip=ip
        self.user_id = user_id
        self.initdb()


    def initdb(self):
        dblink = base_config.get("avmsdb", "dblink")
        #perf_db_name = base_config.get("avmsdb", "perfdbname")
        rawdbname = base_config.get("avmsdb", "rawdbname")
        print "rawdbname: ",rawdbname
        self.client=MongoClient(dblink)
        self.db=self.client[rawdbname]
        self.collection=self.db[rawdbname]

    ###repair bug UnboundLocalError: local variable 'result' referenced before assignment
    def get_test_collection(self,dbname=None,tags=None):
        if self.ip!=():
            cursor=self.collection.find({"number":self.number,"SN":self.sn,"IP":self.ip, "user_id": self.user_id})
        else:
            cursor=self.collection.find({"number":self.number,"SN":self.sn, "user_id": self.user_id})

        if cursor.count() == 0:
            return {"result": "error", "log" : "raw db is not data."}

        name = self.number.split('_')[0]

        for document in cursor:
            tcname=document["tcname"]
            tags = document["tags"]
            print "tcname:",tcname
            tcresult=document["tcresult"]
            result = None ### add this to repair bug
            if tcname =="CPU_SpecINT_rate":
                cpu=SpecCPU_INT_base(self.user_id,dbname)
                cpu.addRecords(tcresult,self.number[0:-25])
                result = cpu.updateRecord2DB()
            elif tcname =="CPU_SpecFP_rate":
                cpu=SpecCPU_FP_base(self.user_id,dbname)
                cpu.addRecords(tcresult,self.number[0:-25])
                result = cpu.updateRecord2DB()
            elif tcname =="CPU_pi":
                cpu=Pi_base(self.user_id,dbname)
                cpu.addRecords(tcresult,self.number[0:-25])
                result = cpu.updateRecord2DB()
            elif tcname =="Power_SpecPower":
                power=SpecPower_base(self.user_id,dbname)
                power.addRecords(tcresult,self.number[0:-25])
                result = power.updateRecord2DB()
            elif tcname =="System_unixbench":
                sys=unixbench_base(self.user_id,dbname)
                sys.addRecords(tcresult,self.number[0:-25])
                result = sys.updateRecord2DB()
            elif tcname =="Mem_Stream_Bandwidth":
                mem=Stream_base(self.user_id,dbname)
                mem.addRecords(tcresult,self.number[0:-25])
                result = mem.updateRecord2DB()
            elif tcname[0:3]==("IO_"):
                if tags == "":
                    print "this is old data!"
                    continue
                else :
                    tag={}
                    tag["fio_type"] = tags["fio"][0]
                    io=fio_base(tcname, self.user_id,dbname,tag)
                    io.addRecords(tcresult,self.number[0:-25])
                    result = io.updateRecord2DB()
            elif tcname[0:9]==("Net_qperf"):
                net=qperf_base(tcname, self.user_id,dbname)
                net.addRecords(tcresult,self.number[0:-25])
                result = net.updateRecord2DB()
            elif tcname==("Memory_MLC"):
                net=mlc_base(self.user_id,dbname)
                net.addRecords(tcresult,self.number[0:-25])
                result = net.updateRecord2DB()
            elif tcname==("Memory_LMbench_BW"):
                net=mem_bw_base(self.user_id,dbname)
                net.addRecords(tcresult,self.number[0:-25])
                result = net.updateRecord2DB()
            elif tcname==("Memory_LMbench_Lat"):
                net=mem_lat_base(self.user_id,dbname)
                net.addRecords(tcresult,self.number[0:-25])
                result = net.updateRecord2DB()
            if  result["result"] == "ok" :#repair bug
                continue
            else:
                return result
        return {"result": "ok"}


if __name__ == "__main__":
    #manager=db_base_manager("T02_speccpu_power_stress_2016-01-13T12:24:01.297Z","2102310YQC10E5000002")
    #manager.get_test_collection()
    if len(sys.argv) != 3:
        print "Please Input Testname and sn";
    else:
        manager=db_base_manager(sys.argv[1], sys.argv[2])
        manager.get_test_collection()
