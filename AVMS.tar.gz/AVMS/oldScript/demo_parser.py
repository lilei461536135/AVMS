class demo(object):
    ###logpath 填写默认日志生成的路径
    def __init__(self,logpath="/tmp/XXX/XXX"):
        self.logpath=logpath
 
    def get_data(self):
        ###
        ###handle the logpath file , return the need json
        ###
    	return data
 
if __name__ == "__main__":
    parser = demo(sys.argv[1])
    data = parser.get_data()
    #return data