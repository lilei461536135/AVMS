
import os
import sys
import re
from db_baseline_base import db_baseline_base
from graph_base import graph_base
from pymongo import MongoClient

class mem_bw_base(db_baseline_base):
    def __init__(self, user_id,dbname=None):
        self.user_id = user_id
        db_baseline_base.__init__(self,"Memory_LMbench_BW", self.user_id,dbname)
        self.init_read_bandwidth()
        self.set_test_command()




    def init_read_bandwidth(self):
        if db_baseline_base.getSubMetric(self,"Memory_Read_Bandwidth") == None :
            rate_peek_graph=graph_base("MB/s","Memory size(MB/s)",[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],"Memory performance:Read Bandwidth as cores increase ","Memory read bandwidth as cores increase test by LMbench",{},{})
            db_baseline_base.addSubMetric(self,"Memory_Read_Bandwidth",rate_peek_graph.data)




    def set_test_command(self,command="bw_mem -P 20 -N 3 4096M rd"):
        if self.data["test_command"]== None or self.data["test_command"]!="bw_mem -P 20 -N 3 4096M rd":
            self.data["test_command"]=command


    def addRecords(self,tcresut,sample):
        list_data = []
        for i in range(1,21):
            list_data.append(tcresut["Memory_Read_Bandwidth"][str(i)+"core"])
        self.addRecord("Memory_Read_Bandwidth",sample,list_data)



if __name__ == "__main__":
    cpu_fp=SpecCPU_FP_base()
    cpu_fp.updateRecord2DB()
    print cpu_fp.collection.find()[0]