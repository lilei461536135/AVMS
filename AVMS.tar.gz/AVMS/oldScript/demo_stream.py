#!/usr/bin/python
#-*-coding: utf-8-*-
import os
import sys
 
dirTest = "/tmp/tools"
 
"""this is test the python"""
 
def run_start():
    print 'stream_test start.'
    path = dirTest + "/mem"
    os.chdir(path)
    cmdRt = os.system("chmod +x stream_test.sh")
    if cmdRt == 0:
        print "chmod stream_test.sh is ok"
    else :
        print "error chmod stream_test.sh "
        sys.exit(-1)
 
def run():
    print "stream_test run."
 
    with open('/tmp/tools/name', 'r') as f:
        path = f.readline()
        path = path.strip('\n')
    cmd = "mkdir -p " + path + "/performance/stream"
    path = path + "/performance"
    print "cmd = ", cmd
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print cmd + " is ok!"
    else :
        print cmd + " is error!"
        sys.exit(-1)
    cmd = "./stream_test.sh &> " + path + "/stream/stream.result"
    print "cmd = ", cmd
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print "run stream_test.sh is ok"
    else :
        print "error run stream_test.sh"
        sys.exit(-1)
 
 
 
def run_end():
    print 'stream_test end.'
 
if __name__ == '__main__':
    run_start()
    run()
    run_end()