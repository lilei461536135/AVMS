import os
import traceback
import sys
import re
from pymongo import MongoClient
from server_description import server_description
from SpecCPU_INT_report import SpecCPU_INT_report
from SpecCPU_FP_report import SpecCPU_FP_report
from UnixBench_report import UnixBench_report
from SpecPower_report import SpecPower_report
from Stream_report import Stream_report
from parserPi import parserPi
from fio_report import fio_report
from qperf_report import qperf_report
from mlc_report import mlc_report
from mem_bw_report import mem_bw_report
from mem_lat_report import mem_lat_report
from BMC_report import BMC_report
from avms_script.test.server_error_entity import error_report
from linpack_report import stress_linpack_report
from memtest_report import stress_mem_report
from ptu_report import stress_ptu_report
from stress_report import stress_stress_report
from fstack.utils import log as logging


LOG = logging.getLogger(__name__)

class db_report_manager(object):
    def __init__(self, pathname, user_id):
        self.pathname=pathname
        self.user_id = user_id
        self.testname=os.path.basename(pathname)
        self.servers=dict()
        self.init_server_description()
        self.categ = 0
        LOG.info("db_report_manager")



    def init_server_description(self):
        for server in os.listdir(self.pathname):
            self.servers[server]=server_description(os.path.join(self.pathname,server),self.testname, self.user_id)

        #self.servers["10.218.169.151"]={
    """server_summary": {
        "Serial Number": "2102310KCS10E9000295",
        "Product Name": "Tecal RH1288 V2-8S",
        "Manufacturer": "Huawei Technologies Co., Ltd.",
        "IP": "10.218.169.151",
        "Vendor": "Insyde Corp.",
        "ServerType": "N32",
        "TestName": "N32xxx"
    }
}"""

    def paser_server_result(self,path):
        #test_path_list = os.listdir(path)
        test_path_dict = {}
        test_path_list = []
        other_list = []
        classify_list = os.listdir(path)
        for item in classify_list:
            if item == 'stress' or item == 'performance':
                for testcase in os.listdir(path + '/' + item):
                    #test_path_list.append(testcase)
                    test_path_dict[testcase] = item
            elif item[0:2] == 'SN':
                other_list.append(item)

        if 'performance' in classify_list:
            if 'stress' in classify_list:
                self.categ = 10
            else:
                self.categ = 0
        elif 'stress' in classify_list:
            if 'performance' in classify_list:
                self.categ = 10
            else:
                self.categ = 1

        test_path_list = test_path_dict.keys()
        test_path_list.extend(other_list)
        ip=os.path.basename(path)
        server=self.servers[ip]
        for test_path in test_path_list:
            if test_path =="speccpu":
                try:
                    cmd="ls -lrt "+os.path.join(path , test_path_dict[test_path], test_path,"CINT2006*.ref.txt")
                    cmd1="ls -lrt "+os.path.join(path, test_path_dict[test_path], test_path,"CFP2006*.ref.txt")
                    str=os.popen(cmd).readlines()[-1].split()[-1]
                    #filepath=os.path.join(path,test_path,str)
                    cpu=SpecCPU_INT_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,str, self.user_id)
                    str=os.popen(cmd1).readlines()[-1].split()[-1]
                    #filepath=os.path.join(path,test_path,str)
                    cpu=SpecCPU_FP_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,str, self.user_id)
                except Exception, e:
                    print e
            elif test_path == "unixbench":
                try:
                    filepath=self.__get_log_path(os.path.join(path, test_path_dict[test_path], test_path),"*.html")
                    unixbench=UnixBench_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id)
                except Exception, e:
                    print traceback.format_exc()
                    print e
            elif test_path == "specPower":
                try:
                    filepath=self.__get_log_path(os.path.join(path, test_path_dict[test_path], test_path),"power*")
                    power=SpecPower_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id)
                except Exception,e:
                    print e
            elif test_path == "stream":
                try:
                    filepath=self.__get_log_path(os.path.join(path, test_path_dict[test_path], test_path),"stream*.result")
                    stream=Stream_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id)
                except Exception, e:
                    print e
            elif test_path == "mlc":
                try:
                    filepath=self.__get_log_path(os.path.join(path, test_path_dict[test_path], test_path),"mlc*.result")
                    stream=mlc_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath,self.user_id)
                except Exception,e:
                    print e
            elif test_path == "lmbench":
                try:
                    filepath=self.__get_log_path(os.path.join(path, test_path_dict[test_path], test_path),"Lmbench_lat.result")
                    stream=mem_lat_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath,self.user_id)
                    filepath=self.__get_log_path(os.path.join(path, test_path_dict[test_path], test_path),"Lmbench_bw.result")
                    stream=mem_bw_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath,self.user_id)
                except Exception, e:
                    print e

            elif test_path == "qperf":
                qperf_list=os.listdir(os.path.join(path, test_path_dict[test_path], test_path))
                for log in qperf_list:
                    try:
                        filepath=os.path.join(path, test_path_dict[test_path], test_path,log)
                        qperf=qperf_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id)
                    except Exception, e:
                        print traceback.format_exc()
                        print e
            elif test_path == "pi":
                try:
                    filepath=self.__get_log_path(os.path.join(path, test_path_dict[test_path], test_path),"pi*.result")
                    pi=parserPi(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id)
                except Exception, e:
                    print e
            elif test_path == "bmc":
                try:
                    filepath=os.path.join(path, test_path)
                    bmc=BMC_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id)
                    bmc.build_record()
                except Exception, e:
                    print e
            elif test_path == "fio":
                logs_list=os.listdir(os.path.join(path, test_path_dict[test_path],test_path))
                for log in logs_list:
                    '''if log[0:2] != 'IO':
                        continue
                    filepath=os.path.join(path,test_path,log)
                    try:
                        fio=fio_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id)
                    except Exception, e:
                        print e'''
                    if log[0:2] == 'IO':
                        filepath=os.path.join(path, test_path_dict[test_path],test_path,log)
                        try:
                            fio=fio_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id)
                        except Exception, e:
                            print e
                    else :
                        filepath=os.path.join(path, test_path_dict[test_path], test_path, log)
                        if os.path.isdir(filepath):
                            depth_log_list = os.listdir(os.path.join(path, test_path_dict[test_path], test_path, log))
                            tags = dict()
                            tags["fio"] = []
                            tags["fio"].append(log)
                            for depth_log in depth_log_list:
                                depth_filepath = os.path.join(filepath, depth_log)
                                try:
                                    fio=fio_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],tags,ip,depth_filepath, self.user_id)
                                except Exception, e:
                                    print e
            elif test_path[0:3] == "SN_":
                try:
                    filepath=os.path.join(path,test_path)
                    sn = test_path.split("_")[1]
                    report = error_report( self.testname,filepath, sn, ip)
                except Exception, e:
                    print e
            elif test_path == "Stress_Cpu_linpack":
                try:
                    filepath = os.path.join(path, test_path_dict[test_path], test_path)
                    stress_linpack = stress_linpack_report(self.testname, server.data["server_summary"]["Serial Number"], server.data["server_summary"]["ServerType"], {}, ip, filepath, self.user_id)
                except Exception, e:
                    print traceback.format_exc()
                    print e
            elif test_path == "Stress_Mem_memtest":
                try :
                    filepath = os.path.join(path, test_path_dict[test_path], test_path)
                    stress_memtest = stress_mem_report(self.testname, server.data["server_summary"]["Serial Number"], server.data["server_summary"]["ServerType"], {}, ip, filepath, self.user_id)
                except Exception , e:
                    print e
            elif test_path == "Stress_Cpu_ptu":
                try :
                    filepath = os.path.join(path, test_path_dict[test_path], test_path)
                    stress_ptu = stress_ptu_report(self.testname, server.data["server_summary"]["Serial Number"], server.data["server_summary"]["ServerType"], {}, ip, filepath, self.user_id)
                except Exception, e:
                    print e
            elif test_path == "Stress_CpuIo_stress":
                try :
                    filepath = os.path.join(path, test_path_dict[test_path], test_path)
                    stres_stress = stress_stress_report(self.testname, server.data["server_summary"]["Serial Number"], server.data["server_summary"]["ServerType"], {}, ip, filepath, self.user_id)
                except Exception, e:
                    print e
            elif test_path == "Stress_Cpu_speccpu":
                try:
                    cmd="ls -lrt "+os.path.join(path , test_path_dict[test_path], test_path,"CINT2006*.ref.txt")
                    cmd1="ls -lrt "+os.path.join(path, test_path_dict[test_path], test_path,"CFP2006*.ref.txt")
                    str=os.popen(cmd).readlines()[-1].split()[-1]
                    #filepath=os.path.join(path,test_path,str)
                    cpu=SpecCPU_INT_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,str, self.user_id, "stress")
                    str=os.popen(cmd1).readlines()[-1].split()[-1]
                    #filepath=os.path.join(path,test_path,str)
                    cpu=SpecCPU_FP_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,str, self.user_id, "stress")
                except Exception, e:
                    print e
            elif test_path == "Stress_Io_fio":
                logs_list=os.listdir(os.path.join(path, test_path_dict[test_path],test_path))
                for log in logs_list:
                    '''if log[0:2] != 'IO':
                        continue
                    filepath=os.path.join(path,test_path,log)
                    try:
                        fio=fio_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id)
                    except Exception, e:
                        print e'''
                    if log[0:2] == 'IO':
                        filepath=os.path.join(path, test_path_dict[test_path],test_path,log)
                        try:
                            fio=fio_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id, "stress")
                        except Exception, e:
                            print e
                    else :
                        filepath=os.path.join(path, test_path_dict[test_path], test_path, log)
                        if os.path.isdir(filepath):
                            depth_log_list = os.listdir(os.path.join(path, test_path_dict[test_path], test_path, log))
                            tags = dict()
                            tags["fio"] = []
                            tags["fio"].append(log)
                            for depth_log in depth_log_list:
                                depth_filepath = os.path.join(filepath, depth_log)
                                try:
                                    fio=fio_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],tags,ip,depth_filepath, self.user_id, "stress")
                                except Exception, e:
                                    print e
            elif test_path == "Stress_Net_qperf":
                qperf_list=os.listdir(os.path.join(path, test_path_dict[test_path], test_path))
                for log in qperf_list:
                    try:
                        filepath=os.path.join(path, test_path_dict[test_path], test_path,log)
                        qperf=qperf_report(self.testname,server.data["server_summary"]["Serial Number"],server.data["server_summary"]["ServerType"],{},ip,filepath, self.user_id, "stress")
                    except Exception, e:
                        print traceback.format_exc()
                        print e


    def parser_servers(self,path):

        for server in self.servers:
            try:
                self.paser_server_result(os.path.join(self.pathname,server))
            except Exception,e:
                print e

    def __get_log_path(self,ppath,filename):
        cmd="ls -lrt "+os.path.join(os.path.abspath(ppath),filename)
        #print cmd
        #print os.popen(cmd).readlines()[-1]
        #print os.popen(cmd).readlines()[0].split()
        str=os.popen(cmd).readlines()[-1].split()[-1]
        #print str
        #filepath=os.path.join(ppath,str)
        LOG.debug(str)
        return str




if __name__ == '__main__':
    #manager=db_report_manager("/Users/maxuhua/Desktop/F41_speccpu_power_stress_2016-01-13T12:24:01.297Z")
    #manager=db_report_manager("/home/psl/Desktop/H42_all_2016-02-18T03:34:33.411Z")
    #manager.parser_servers(manager.pathname)
    #manager = db_report_manager("")
    manager = db_report_manager("/var/www/html/result/admin/avmslog/Zhuque_performance_2016-05-14-13:56:51", "admin")
    manager.parser_servers(manager.pathname)
    '''if len(sys.argv) != 2:
        print "Please Input PATH."
        sys.exit(-1)
    else:
        print "argv[1] : " ,sys.argv[1]
        manager=db_report_manager(sys.argv[1])
        manager.parser_servers(manager.pathname)'''

