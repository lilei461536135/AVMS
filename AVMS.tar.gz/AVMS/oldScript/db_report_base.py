import os
import sys
import re
from pymongo import MongoClient
from fstack.utils.baseconfig import base_config


class db_report_base(object):
    def __init__(self, number, SN,Type,dev_mode,tags,tcname,tcresult,IP, user_id, category):
        self.data = dict()
        self.data["number"] = number
        self.data["SN"] = SN
        self.data["IP"] = IP
        self.data["Type"] = Type
        self.data["dev_mode"] = dev_mode
        self.data["tags"] = tags
        self.data["tcname"] = tcname
        self.data["tcresult"] = tcresult
        self.data["user_id"] = user_id
        self.data["category"] = category
        dblink = base_config.get("avmsdb", "dblink")
        perf_db_name = base_config.get("avmsdb", "perfdbname")
        rawdbname = base_config.get("avmsdb", "rawdbname")
        self.client = MongoClient(dblink)
        self.db = self.client[rawdbname]
        self.coll = self.db[rawdbname]
        #self.db = self.client.perf12
        #self.coll = self.db.perf12

    def record2json(self):
       return {
           "number":self.__number,
           "SN":self.__SN,
           "Type":self.__Type,
           "dev_mode":self.__dev_mode,
           "IP":self.__IP,
           "tags":self.__tags,
           "tcname":self.__tcname,
           "tcresult":self.__tcresult
       }

    def parser(self,filename):
        pass


    def insert2reportdb(self):
        """

        :param data:
        """
        #data=self.record2json()
        cursor = self.coll.find({"number":self.data["number"], "SN" : self.data["SN"], "tcname":self.data["tcname"], "IP": self.data["IP"], "tags":self.data["tags"], "category": self.data["category"]})
        if cursor.count() >= 1:
            print "the record is already exist,the add action is not allowed %s, %s", self.data["number"], self.data["SN"]
            return "error"
        else:
            self.coll.insert_one(self.data)
            print "insert db is ok"
            return "ok"



    def get_record(self):
        client = MongoClient("mongodb://10.125.6.97:27017")
        print "connect the db."
        db = client.perf11
        coll = db.perf11
        print coll.find({"number":self.data["number"]})[0]
        return coll.find({"number":self.data["number"]})[0]


    def getValue(self,key):
        return self.data[key]

    def SetValue(self,key,value):
        self.data[key]=value




