import os
import sys
import re
from db_baseline_base import db_baseline_base
from graph_base import graph_base
from pymongo import MongoClient

class Stream_base(db_baseline_base):
    def __init__(self, user_id,dbname=None):
        self.user_id = user_id
        db_baseline_base.__init__(self,"Mem_Stream_Bandwidth", self.user_id,dbname)
        self.init_Stream_BW()
        self.set_test_command()



    def init_Stream_BW(self):
        if db_baseline_base.getSubMetric(self,"Stream_Memory_Bandwidth") == None :
            graph=graph_base("Bandwidth (MB/s)","FP_Rate_Peek_total",[],"Stream Memory Bandwidth","Stream Memory Bandwidth",{},{})
            db_baseline_base.addSubMetric(self,"Stream_Memory_Bandwidth",graph.data)

    def addRecords(self,tcresult,sample):
        self.addRecord("Stream_Memory_Bandwidth",sample,tcresult["Triad"]["bandwith"])

    def set_test_command(self,command="sh stream_test.sh"):
        if self.data["test_command"]== None or self.data["test_command"]!="sh stream_test.sh":
            self.data["test_command"]=command



if __name__ == "__main__":
    mem=Stream_base()
    mem.addRecord("Stream_Memory_Bandwidth","D32","21")
    mem.addRecord("Stream_Memory_Bandwidth","D33",["22","11","22","33"])
    mem.updateRecord2DB()