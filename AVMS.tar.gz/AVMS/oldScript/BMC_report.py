from db_report_base import db_report_base
import os
import re
from pymongo import MongoClient
import json
from BMC_parser import BMC_parser
from fstack.utils import log as logging

LOG = logging.getLogger(__name__)

#class BMC_report(object):
class BMC_report(db_report_base):


    def __init__(self,number, SN,dev_mode,tags,IP,filename, user_id):
        self.filename=filename
        self.user_id = user_id
        self.number=number
        self.SN=SN
        self.dev_mode=dev_mode
        self.tags=tags
        self.IP=IP
        self.parser=BMC_parser(self.filename)




    def __gettcs__(self):
        cmd={}
        cmd["cmdbmc"]="ls "+os.path.join(self.filename,"BMC*.log")
        cmd["cmdrmc"]="ls "+os.path.join(self.filename,"RMC*.log")
        cmd["cmdbios"]="ls "+os.path.join(self.filename,"BIOS*.log")
        logs=[]
        for key in cmd.keys():

            str=os.popen(cmd[key]).readlines()
            print str
            print cmd[key]
            logs.extend(os.popen(cmd[key]).readlines())

        tcs=[]
        for log in logs:
            tmp=os.path.basename(log)
            tcs.append(tmp[:-5])
        return tcs

    def build_record(self):

        for tc in self.__gettcs__():
            #model=tc[:3] if tc[3:4]=="_" else tc[:4]
            model = tc.split('_')[0]
            funcname="get_"+tc
            output_function = getattr(self.parser, funcname,"Non")
            tcresult={}
            if output_function =="Non":
                print "ERROR:there is no parser function : %s" % (funcname)
                LOG.error("ERROR:there is no parser function : %s",funcname)

            else:
                try:
                    tcresult=output_function()
                except Exception, e:
                    print e
                    LOG.error("ERROR:there is no parser function : %s",e)

            db_report_base.__init__(self,self.number, self.SN,model,self.dev_mode,self.tags,tc,tcresult,self.IP, self.user_id, "performance")
            self.insert2reportdb()
            #print "ok"



if __name__ == "__main__":
    report=BMC_report("number", "SN","dev_mode","tags","IP","test/bmc","user_id",)
    report.build_record()
