from db_report_base import db_report_base
import os
import re
from pymongo import MongoClient
import json


class mem_bw_report(db_report_base):

    def __init__(self,number, SN,dev_mode,tags,IP,filename, user_id):
        self.filename=filename
        self.user_id = user_id
        tcresult=self.parser(filename)
        self.matricname=os.path.basename(filename).split('.')[0]
        db_report_base.__init__(self,number, SN,"Memory",dev_mode,tags,"Memory_LMbench_BW",tcresult,IP, user_id , "performance")
        self.insert2reportdb()



    def parser(self,filename):
        data=dict()
        data["Memory_Read_Bandwidth"]=self.get_read_bw()
        return data


    def get_read_bw(self):
        cmd='cat ' + self.filename
        tdata=os.popen(cmd).readlines()
        data=dict()
        index=1
        for line in tdata:
            value=line.split()[1].strip()
            data[str(index)+"core"]=value
            index=index+1
        return data



if __name__ == "__main__":
    #tmp='{"fio version" : "fio-2.0000000","70>=0000":20}'
    #tmp1='{"aaaa":"bbbb","aaa":1111}'
    #data=json.loads(tmp,encoding="utf-8")
    #(self,number, SN,dev_mode,tags,IP,filename, user_id):
    #cpu=mlc_report("numberfio33","SN2fio33","N31_fio","N31-xxxs-fio","baselinefio","192.168.1.1","test/mlc.log", "test")
    cpu=mem_lat_report("numberfio33","SN2fio33","N31_fio","baselinefio","192.168.1.1","test/Lmbench_lat.result", "test")
    #cpu.coll.insert_one(data)
    cpu.insert2reportdb()
