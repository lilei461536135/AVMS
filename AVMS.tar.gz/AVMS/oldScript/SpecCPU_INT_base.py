import os
import sys
import re
from db_baseline_base import db_baseline_base
from graph_base import graph_base
from pymongo import MongoClient

class SpecCPU_INT_base(db_baseline_base):
    def __init__(self, user_id,dbname=None,tags=None):
        self.user_id = user_id
        db_baseline_base.__init__(self,"CPU_specINT_rate", self.user_id,dbname,tags)
        self.init_rate_peek()
        self.init_rate_base()
        self.set_test_command()



    def init_rate_peek(self):
        if db_baseline_base.getSubMetric(self,"INT_Rate_Peek_total") == None :
            rate_peek_graph=graph_base("SPECint@2006","INT_Rate_Peek_total",[],"SpecCPU INT_Rate_Peek_total","SpecCPU INT Rate",{},{})
            db_baseline_base.addSubMetric(self,"INT_Rate_Peek_total",rate_peek_graph.data)

    def init_rate_base(self):
        if db_baseline_base.getSubMetric(self,"INT_Rate_Base_total") == None :
            rate_base_graph=graph_base("SPECint_base2006","INT_Rate_Base_total",[],"SpecCPU INT_Rate_Base_total","SpecCPU INT Rate",{},{})
            db_baseline_base.addSubMetric(self,"INT_Rate_Base_total",rate_base_graph.data)

    def set_test_command(self,command="sh new.reportable-avx-smt-on-rate.sh"):
        if self.data["test_command"]==None or self.data["test_command"]!="sh new.reportable-avx-smt-on-rate.sh":
            self.data["test_command"]=command

    def addRecords(self,tcresut,sample):
        self.addRecord("INT_Rate_Peek_total",sample,tcresut["INT_Rate_Peek_total"])
        self.addRecord("INT_Rate_Base_total",sample,tcresut["INT_Rate_Base_total"])





