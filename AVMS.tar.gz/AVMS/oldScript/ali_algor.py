# -*- coding: utf-8 -*-

class TextAlgor(object):
	@staticmethod
	def nop(src, dst):
		return True

	@staticmethod
	def ainAb(src,dst):
		try:
			if src.lower() in dst.lower() or dst.lower() in src.lower():
				return True
		except Exception,e:
			print str(e)

		return False

	@staticmethod
	def equal(src, dst):
		return src==dst


	@staticmethod
	def match(src, dst):
		return str(src).strip().lower() == str(dst).strip().lower()


	'''@staticmethod
	def gt(src, dst):
		if type(src) != type(dst):
			return str(src) > str(dst)

		return src>dst'''
#change 4/12 psl
	@staticmethod
	def gt(src, dst):
		if src == "None":
			return "NoResult"
		if src == None:
			return "NoResut"
		if type(src) != type(dst):
			try:
				return float(src) >= float(dst)
			except:
				return "NA"
		else:
			try:
				if float(src) >= float(dst):
					return "Pass"
				else :
					return "Fail"
			except:
				return "NA"
			#return float(src) > float(dst)
###add 4/13 psl
	@staticmethod
	def lt(src, dst):
		if src == "None":
			return "NoResult"
		if src == None:
			return "NoResult"
		if type(src) != type(dst):
			try:
				return float(src) <= float(dst)
			except:
				return "NA"
		else:
			try:
				if float(src) >= float(dst):
					return "Fail"
				else:
					return "Pass"
			except:
				return "NA"
			#return float(src) < float(dst)

	@staticmethod
	def version_gte(src, dst):
		src_ver = [i.lstrip("0") for i in src.split(".")]
		dst_ver = [i.lstrip("0") for i in dst.split(".")]
		if len(src_ver) != len(dst_ver):
			return False

		for idx,v in enumerate(src_ver):
			if v.isdigit():
				if int(src_ver[idx]) < int(dst_ver[idx]):
					return False
			else:
				if src_ver[idx] < dst_ver[idx]:
					return False

		return True

	@staticmethod
	def version_equal(src, dst):
		src_ver = [i.lstrip("0") for i in src.split(".")]
		dst_ver = [i.lstrip("0") for i in dst.split(".")]
		if len(src_ver) != len(dst_ver):
			return False

		for idx,v in enumerate(src_ver):
			if src_ver[idx] != dst_ver[idx]:
				return False

		return True