from pymongo import MongoClient
from fstack.utils.baseconfig import base_config

class get_db(object):
    def __init__(self, number, sn, user_id):
        self.number = number
        self.sn = sn
        self.user_id = user_id
        self.collection = self.get_data()

    def get_data(self):
        #client = MongoClient("mongodb://10.125.201.46:27017/")
        #db = client["perf11"]
        #coll = db["perf11"]
        dblink = base_config.get("avmsdb", "dblink")
        #perf_db_name = base_config.get("avmsdb", "perfdbname")
        rawdbname = base_config.get("avmsdb", "rawdbname")
        client=MongoClient(dblink)
        db = client[rawdbname]
        coll = db[rawdbname]
        return coll