#!/usr/bin/python
# -*- coding: UTF-8 -*-

from db_report_base import db_report_base
import string
import os

class qperf_report(db_report_base) :
    def __init__(self, number, SN, dev_mode, tags, IP, filename, user_id, category="performance"):
        self.matricname=os.path.basename(filename)[0:-20]
        tcresult = self.parser(filename)
        db_report_base.__init__(self,number, SN, "Network", dev_mode, tags, self.matricname, tcresult, IP, user_id, category)
        db_report_base.insert2reportdb(self)

    def parser(self, filename):
        tcresult = dict()
        print "paser filename: ", filename
        with open(filename) as fp:
            tcpOrudp = 3
            i = 1
            n = 1
            while 1:
                line_data = fp.readline()
                if len(line_data) == 0:
                    break
                else:
                    #print line_data
                    import3chart = line_data[0:3]
                    #print import3chart
                    if import3chart == 'tcp':
                        #print "tcp :: ok "
                        n = n * 2
                        tcpOrudp = 1
                        #tcresult["test_item"] = line_data[0:len(line_data) - 2]
                        tcresult[str(n)] = dict()
                        continue
                    elif import3chart == 'udp':
                        #print "udp :: ok"
                        n = n * 2
                        tcpOrudp = 0
                        #tcresult["test_item"] = line_data[0:len(line_data) - 2]
                        tcresult[str(n)] = dict()
                        continue
                    elif import3chart == 'cmd':
                        tcpOrudp = 2
                        tcresult["cmd"] = line_data.split("=")[1]
                        continue

                    if tcpOrudp != 2:
                        #tcresult[i] = dict()
                        detailNum = line_data.strip('\n').strip(' ').split('=')
                        #print detailNum[0].strip(' '), detailNum[1].strip(' ')
                        #print line_data
                        #print detailNum
                        tcresult[str(n)][detailNum[0].strip(' ')] = detailNum[1].strip(' ')

                i = i +1
                print i
        #print tcresult
        return tcresult

if __name__ == "__main__":
    fq = parserQperf("1111", "2222", "3333", "4444", "5555", "6666", "7777", "/home/psl/AVMS2/src/script/qperf/Net_qperf_udp_bw_by_message_size_2016_01_27_10_00_22")
