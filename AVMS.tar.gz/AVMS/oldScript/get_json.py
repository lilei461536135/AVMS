

def process_OS_cpuinfo(path):
    print 'process the file ', path
    with open(path) as fp :
        print 'open the ' + path + " is ok!"
        os_cpuinfo = dict()
        os_cpuinfo["cpuinfo"] = dict()
        #os_cpuinfo["cpuinfo"][]
        str = fp.readlines()
        processId = 0
        os_cpuinfo["cpuinfo"][processId] = dict()
        for line in str:
            if line == '\n':
                processId = processId + 1
                os_cpuinfo["cpuinfo"][processId] = dict()
                continue
            detailLine = line.strip('\n').split(':')
            print detailLine
            os_cpuinfo["cpuinfo"][processId][detailLine[0]] = detailLine[1]
            #os_cpuinfo["cpuinfo"][processId][] =
        print os_cpuinfo
        return os_cpuinfo


def process_Network(path):
    print 'process the file ', path
    with open(path) as fp:
        #print 'open the ' + path + ' is ok!'
        network_info = dict()
        network_info["Networks"] = dict()
        #str = fp
        item = ""
        parent = ""
        str = fp.readlines()
        for p in str:
            if p[0:12] == '------------':
                p = p[12:len(p)]
                #print p.strip('\n').split('-----------')
                title_item = p.strip('\n').split('-----------')[0]
                item = title_item.split(' ')[0]
                ##
                #print "item : ", item
                try :
                    if isinstance(network_info["Networks"][item], dict):
                        pass
                    else:
                        network_info["Networks"][item] = dict()
                        #print type(network_info["Networks"][item])
                except:
                    network_info["Networks"][item] = dict()
                    #print 'new network_info["Networks"][' + item + ']'
                continue
            #print p.split(':')
            detail_item = p.split(':')
            if len(detail_item) == 2 and detail_item[1] == '\n':
                #print detail_item
                network_info["Networks"][item][detail_item[0]] = dict()
                parent = detail_item[0]
                continue
            if detail_item[0][0:4] == '    ':
                network_info["Networks"][item][parent][detail_item[0][5:len(detail_item[0])]] = detail_item[1]
                #print detail_item[0][5:len(detail_item[0])]
                #print detail_item[1]
            else:
                try :
                    #print "detail_item : ", detail_item[0], detail_item[1]
                    network_info["Networks"][item][detail_item[0]] = detail_item[1]
                except:
                    continue

    #print network_info

    return network_info


def process_bmc(path):
    print 'process the bmc.'
    type = 100
    with open(path) as fp:
        print 'open the file ' + path + 'is ok.'
        process_bmc = dict()
        process_bmc["BMC"] = dict()
        str = fp.readlines()
        tmp = ''
        for p in str:
            if type == 1 and p[0:9] != '---------':
                detail_item = p.strip('\n').split(':')
                if len(detail_item) < 2:
                    continue
                else :
                    #print "testtest", detail_item
                    #print " TYPE : ", type
                    #process_bmc["BMC"]["FRU"][detail_item[0].strip(' ')] = detail_item[1]
                    process_bmc["BMC"]["FRU"][detail_item[0].strip()] = detail_item[1]
                continue
            elif type == 2 and p[0:9] != '---------':
                detail_item = p.strip('\n').split(':')
                #print "detail_item version : ", detail_item
                if len(detail_item) == 2:
                    if detail_item[1] == '' or detail_item[1] == ' ':
                        #print 'pslpslpsl'
                        process_bmc["BMC"]["version"][detail_item[0].strip(' ')] = []
                        tmp = detail_item[0].strip(' ')
                        continue
                    process_bmc["BMC"]["version"][detail_item[0].strip(' ')] = detail_item[1]
                    continue
                elif len(detail_item) == 1:
                    #print 'tmp : ', tmp, " , detail_item[0] : ", detail_item[0]
                    process_bmc["BMC"]["version"][tmp].append(detail_item[0])
                    #print process_bmc["BMC"]["version"][tmp]["list"]
                    continue
            elif type == 3 and p[0:9] != '---------':
                #print detail_item
                detail_item = p.strip('\n').split('|')
                #print "SDR : ", detail_item
                if len(detail_item) == 3:
                    process_bmc["BMC"]["SDR"][detail_item[0].strip(' ').replace('.','_')] = []
                    process_bmc["BMC"]["SDR"][detail_item[0].strip(' ').replace('.','_')].append(detail_item[1])
                    process_bmc["BMC"]["SDR"][detail_item[0].strip(' ').replace('.','_')].append(detail_item[2])
                continue
            elif type == 4 and p[0:9] != '---------':
                #print "user:", p
                #detail_item = p.strip('\n').split()
                if p[0] == 'I'or p[0] == '\n':
                    continue
                else :
                    process_bmc["BMC"]["user"][p[4:21]] = p[21:len(p)]
                #print "user0-4:", p[4:21]
                continue
            elif type == 6 and p[0:9] != '---------':
                #print p
                detail_item = p.strip('\n').split(':')
                #print "LAN :", detail_item
                if len(detail_item) == 2:
                    process_bmc["BMC"]["LAN"][detail_item[0].replace('.','_')] = detail_item[1]
                continue

            #print p[0:9]
            if p[0:12] == '---------FRU':
                process_bmc["BMC"]["FRU"] = dict()
                type = 1
                continue
            elif p[0:16] == '---------version':
                process_bmc["BMC"]["version"] = dict()
                type = 2
                continue
            elif p[0:12] == '---------SDR':
                process_bmc["BMC"]["SDR"] = dict()
                type = 3
                continue
            elif p[0:13] == '---------user':
                process_bmc["BMC"]["user"] = dict()
                type = 4
                continue
            elif p[0:12] == '---------SEL':
                type = 5
            elif p[0:12] == '---------LAN':
                process_bmc["BMC"]["LAN"] = dict()
                type = 6
                continue
            else :
                type = 100
            continue
    #print process_bmc
    import_key = ["Product Name", "Product Manufacturer", "Chassis Part Number"]
    print "test1", process_bmc.get("BMC").get("FRU").get("Product Name", "not Found Product Name")
    for item in import_key:
        tmp = process_bmc.get("BMC").get("FRU").get(item, "None")
        if tmp == "None":
            process_bmc["BMC"]["FRU"][item] = "None"
    return process_bmc


def process_bios(path):
    print 'path is the file ', path
    with open(path) as fp :
        process_bios = dict()
        process_bios["BIOS"] = dict()
        str = fp.readlines()
        i = 0
        for p in str:
            if "BIOS Information" in p:
                i = 1
                continue
            if i == 1:
                detail_item = p.strip('\t').split(':')
                if len(detail_item) == 2:
                    print "BIOS : ", detail_item
                    process_bios["BIOS"][detail_item[0].strip(' ')] = detail_item[1]
        print process_bios

        return process_bios

def process_hwqc_bios():
    ##check the hwqc and python
    if not os.path.isfile("/usr/alisys/dragoon/libexec/hwqc/hwqc.py"):
        #install hwqc
        pass
    ##if not hwqc and python   install it
    bios_cmd_list = ["turbo", "ht", "vt", "hdprefetcher", "numa", "bootorder"]
    bios_hwqc_info = dict()
    for item in bios_cmd_list:
        cmd = "/home/tops/bin/python /usr/alisys/dragoon/libexec/hwqc/hwqc.py bios --task " + item + " --action show"
        bios_hwqc_info[item] = os.popen(cmd).read()
    return bios_hwqc_info


if __name__ == "__main__":
    #process_OS_cpuinfo("/home/psl/AVMS2/src/script/F42_speccpu_power_stress_2016-01-13T12:24:01.297Z/10.218.169.151/SN_CV4035AN018/OS_cpuinfo_2016_01_13_20_41_45")
    #process_Network("/home/psl/AVMS2/src/script/F42_speccpu_power_stress_2016-01-13T12:24:01.297Z/10.218.169.151/SN_CV4035AN018/Network_info_2016_01_13_20_41_38")
    #process_bmc("/home/psl/AVMS2/src/script/F42_speccpu_power_stress_2016-01-13T12:24:01.297Z/10.218.169.151/SN_CV4035AN018/BMC_info_2016_01_13_20_41_34")
    process_bios("/home/psl/AVMS2/src/script/F42_speccpu_power_stress_2016-01-13T12:24:01.297Z/10.218.169.151/SN_CV4035AN018/BIOS_sum_2016_01_13_20_41_45")
