#!/usr/bin/python
#-*- coding : UTF-8 -*-
from pymongo import MongoClient
from fstack.utils.baseconfig import base_config

class BaseFormat:
    def __init__(self):
        self.data = dict()
        self.data["number"] = ""
        self.data["SN"] = ""
        self.data["IP"] = ""
        self.data["Type"] = ""
        self.data["dev_mode"] = ""
        self.data["tags"] = ""
        self.data["tcname"] = ""
        self.data["tcresult"] = dict()

    def insertDB(self):
        ''' insert the useful data to db'''
        dblink = base_config.get("avmsdb", "dblink")
        perf_db_name = base_config.get("avmsdb", "perfdbname")
        client = MongoClient(dblink)
        print "connect the db."
        db = client.perf1
        coll = db.perf1
        coll.insert_one(self.data)
        print "insert db is ok"

    def parserFile():
        ''' parser some file, get the useful data'''
        pass
#base = BaseFormat();
