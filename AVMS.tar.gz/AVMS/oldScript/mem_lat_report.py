from db_report_base import db_report_base
import os
import re
from pymongo import MongoClient
import json


class mem_lat_report(db_report_base):

    def __init__(self,number, SN,dev_mode,tags,IP,filename, user_id):
        self.filename=filename
        self.user_id = user_id
        tcresult=self.parser(filename)
        self.matricname=os.path.basename(filename).split('.')[0]
        db_report_base.__init__(self,number, SN,"Memory",dev_mode,tags,"Memory_LMbench_Lat",tcresult,IP, user_id, "performance")
        self.insert2reportdb()



    def parser(self,filename):
        data=dict()
        data["Memory_Latency"]=self.get_latency()
        return data


    def get_latency(self):
        cmd='cat ' + self.filename+'|grep "stride=1024" -A 146'
        tdata=os.popen(cmd).readlines()
        #tdata =
        data=dict()
        tdata = tdata[1:]
        for line in tdata:
            key=line.split()[0].strip().replace('.','_')
            #print "key:", key
            value=line.split()[1].strip()
            #print "value:",value
            data[key]=value
        return data



if __name__ == "__main__":
    #tmp='{"fio version" : "fio-2.0000000","70>=0000":20}'
    #tmp1='{"aaaa":"bbbb","aaa":1111}'
    #data=json.loads(tmp,encoding="utf-8")
    #(self,number, SN,dev_mode,tags,IP,filename, user_id):
    #cpu=mlc_report("numberfio33","SN2fio33","N31_fio","N31-xxxs-fio","baselinefio","192.168.1.1","test/mlc.log", "test")
    cpu=mem_lat_report("numberfio33","SN2fio33","N31_fio","baselinefio","192.168.1.1","test/Lmbench_lat.result", "test")
    #cpu.coll.insert_one(data)
    cpu.insert2reportdb()
