
import os
import sys
import re
import json
import subprocess





class BMC_parser(object):
    def __init__(self,logpath):
        self.logpath=logpath

    def __get_RawData__(self,sdr,sen,oem):

        cmd={"Sdr":sdr,"Sensor":sen,"OEM":oem}
        tdata={}

        for key in ["Sdr","Sensor","OEM"]:
            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"
            else:

                tdata[key]=tmpdata[0].strip()

        if "N/A" in tdata.values():
            tdata["gap"]="N/A"
            return tdata
        try:
            tmp=sorted( tdata.values(),cmp=lambda x,y:cmp(float(x),float(y)))
            tdata["Gap"]=str(float(tmp[-1])-float(tmp[0]))
        except Exception,e:
            print Exception,":",e
            tdata["Gap"]="N/A"
        return tdata

    def get_BMC_Sensor_CPU0_Power(self,filename="BMC_Sensor_CPU0_Power.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_CPU0_Temp(self,filename="BMC_Sensor_CPU0_Temp.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_CPU1_Power(self,filename="BMC_Sensor_CPU1_Power.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata


    def get_BMC_Sensor_CPU1_Temp(self,filename="BMC_Sensor_CPU1_Temp.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "


        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata


    def get_BMC_Sensor_DIMMG0_Power(self,filename="BMC_Sensor_DIMMG0_Power.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata


    def get_BMC_Sensor_DIMMG0_Temp(self,filename="BMC_Sensor_DIMMG0_Temp.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "


        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_DIMMG1_Power(self,filename="BMC_Sensor_DIMMG1_Power.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_DIMMG1_Temp(self,filename="BMC_Sensor_DIMMG1_Temp.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_FAN_0(self,filename="BMC_Sensor_FAN_0.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_FAN_1(self,filename="BMC_Sensor_FAN_1.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_FAN_2(self,filename="BMC_Sensor_FAN_2.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_FAN_3(self,filename="BMC_Sensor_FAN_3.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_FAN_4(self,filename="BMC_Sensor_FAN_4.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_FAN_5(self,filename="BMC_Sensor_FAN_5.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_FAN_6(self,filename="BMC_Sensor_FAN_6.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata


    def get_BMC_Sensor_FAN_7(self,filename="BMC_Sensor_FAN_7.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_Inlet_Temp(self,filename="BMC_Sensor_Inlet_Temp.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_Outlet_Temp(self,filename="BMC_Sensor_Outlet_Temp.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_PSU0_Power(self,filename="BMC_Sensor_PSU0_Power.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_PSU1_Power(self,filename="BMC_Sensor_PSU1_Power.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_SYS_12V(self,filename="BMC_Sensor_SYS_12V.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "


        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Sensor_Total_Power(self,filename="BMC_Sensor_Total_Power.log"):

        sdr_cmd="cat "+os.path.join(self.logpath,filename)+" | grep -A  1 'sdr' |tail -n 1  | awk  '{print $9}'"
        sen_cmd="cat "+os.path.join(self.logpath,filename)+  " | grep  -A  1 'sensor' |tail -n 1  | awk  '{print $3}'"
        oem="cat "+os.path.join(self.logpath,filename)+   "| grep 'OEM' |cut -d '(' -f2 |cut -d ')' -f1 "

        tdata=self.__get_RawData__(sdr_cmd,sen_cmd,oem)

        return tdata

    def get_BMC_Chennel_1_check_local(self,filename="BMC_Chennel_1_check_local.log"):

        Channel_Medium_Type="cat "+os.path.join(self.logpath,filename)+" | grep 'Channel Medium Type' | awk -F ':[ ]+' '{print $2}'"


        cmd={"Channel_Medium_Type":Channel_Medium_Type}
        tdata={}

        for key in ["Channel_Medium_Type"]:
            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_Chennel_6_check_local(self,filename="BMC_Chennel_6_check_local.log"):

        Channel_Medium_Type="cat "+os.path.join(self.logpath,filename)+" | grep 'Channel Medium Type' | awk -F ':[ ]+' '{print $2}'"


        cmd={"Channel_Medium_Type":Channel_Medium_Type}
        tdata={}

        for key in ["Channel_Medium_Type"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_Communication_local(self,filename="BMC_Communacation_local.log"):

        Device_ID="cat "+os.path.join(self.logpath,filename)+" | grep 'Device ID' | awk -F\ ':[ ]+' '{print $2}'"
        BMC_FW="cat "+os.path.join(self.logpath,filename)+  " | grep 'Firmware Revision' | awk  -F\ ':[ ]+' '{print $2}'"

        cmd={"Device_ID":Device_ID,"firmware_revision":BMC_FW}
        tdata={}
        for key in ["Device_ID","firmware_revision"]:
            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_Communication_remote(self,filename="BMC_Communacation_remote.log"):

        Device_ID="cat "+os.path.join(self.logpath,filename)+" | grep 'Device ID' | awk -F\ ':[ ]+' '{print $2}'"
        BMC_FW="cat "+os.path.join(self.logpath,filename)+  " | grep 'Firmware Revision' | awk  -F\ ':[ ]+' '{print $2}'"

        cmd={"Device_ID":Device_ID,"firmware_revision":BMC_FW}
        tdata={}

        for key in ["Device_ID","firmware_revision"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_CPU_utilization(self,filename="BMC_CPU_utilization.log"):

        CPU_Utilization="cat "+os.path.join(self.logpath,filename)+" | grep 'ME_CPU_loading %' | awk -F ':[ ]+' '{print $2}'"


        cmd={"CPU_Utilization":CPU_Utilization}
        tdata={}

        for key in ["CPU_Utilization"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_Fru_print_response_time(self,filename="BMC_Fru_print_response_time.log"):

        Time="cat "+os.path.join(self.logpath,filename)+" | grep 'real' | awk '{print $2}'"

        cmd={"Time":Time}
        tdata={}

        for key in ["Time"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_FW_Update_Downgrade(self,filename="BMC_FW_Update_Downgrade.log"):

        count="cat "+os.path.join(self.logpath,filename)+" | grep  'count' | awk  -F \ ':[ ]+' '{print $2}'"
        Fru_check="cat "+os.path.join(self.logpath,filename)+  " | grep 'Check fru' | awk  -F \ ':[ ]+' '{print $2}'"
        User_check="cat "+os.path.join(self.logpath,filename)+  " | grep 'Check User' | awk  -F \ ':[ ]+' '{print $2}'"
        MAC_check="cat "+os.path.join(self.logpath,filename)+  " | grep 'Check MAC' | awk  -F \ ':[ ]+' '{print $2}'"
        SEL_timestamp="cat "+os.path.join(self.logpath,filename)+  " | grep 'Timestamp' | tail -n 1 | awk  -F \ ':[ ]+' '{print $2}'"


        cmd={"count":count,"Fru_check":Fru_check,"User_check":User_check,"MAC_check":MAC_check,"SEL_timestamp":SEL_timestamp}
        tdata={}

        for key in ["count","Fru_check","User_check","MAC_check","SEL_timestamp"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_Lan_print_response_time(self,filename="BMC_Lan_print_response_time.log"):

        Time="cat "+os.path.join(self.logpath,filename)+" |grep 'real'|awk '{print $2}'|awk -F . '{print $2}'"

        cmd={"Time":Time}
        tdata={}

        for key in ["Time"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_Remote_local_Fru(self,filename="BMC_Remote_local_Fru.log"):

        Product_Manufacturer="cat "+os.path.join(self.logpath,filename)+" | grep 'check Product Manufacturer' | awk  -F ':[ ]+' '{print $2}'"
        system_manufacturer="cat "+os.path.join(self.logpath,filename)+" | grep -A 2 'check system manufacturer' | tail -n 1"

        Product_Name="cat "+os.path.join(self.logpath,filename)+" | grep 'check Product Name' | awk  -F ':[ ]+' '{print $2}'"
        system_product_name="cat "+os.path.join(self.logpath,filename)+" | grep -A 2 'check system-product-name' | tail -n 1"

        Product_Serial="cat "+os.path.join(self.logpath,filename)+" | grep 'check Product Serial' | awk  -F ':[ ]+' '{print $2}'"
        system_serial_number="cat "+os.path.join(self.logpath,filename)+" | grep -A 2 'check system-serial-number' | tail -n 1"

        Product_Asset_Tag="cat "+os.path.join(self.logpath,filename)+" | grep 'check Product Asset Tag' | awk  -F ':[ ]+' '{print $2}'"
        chassis_asset_tag="cat "+os.path.join(self.logpath,filename)+" | grep -A 2 'check chassis-asset-tag' | tail -n 1"

        Chassis_Part_Number="cat "+os.path.join(self.logpath,filename)+" | grep 'check Chassis Part Number' | awk  -F ':[ ]+' '{print $2}'"
        chassis_version="cat "+os.path.join(self.logpath,filename)+" | grep -A 2 'check chassis-version' | tail -n 1"

        compare_result="cat "+os.path.join(self.logpath,filename)+" | grep 'compare_result' | awk -F ':[ ]+' '{print $2}'"



        cmd={"Product_Manufacturer":Product_Manufacturer,"Product_Name":Product_Name,"Product_Serial":Product_Serial,"Product_Asset_Tag":Product_Asset_Tag,"Chassis_Part_Number":Chassis_Part_Number}
        tdata={}
        for key in ["Product_Manufacturer","Product_Name","Product_Serial","Product_Asset_Tag","Chassis_Part_Number"]:
            tmpdata=os.popen(cmd[key]).readlines()
            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"
            else:
                tdata[key]=tmpdata[0].strip()



        cmd={"system_manufacturer":system_manufacturer,"system_product_name":system_product_name,"system_serial_number":system_serial_number,"chassis_asset_tag":chassis_asset_tag,"chassis_version":chassis_version}
        tdata2={}
        for key in ["system_manufacturer","system_product_name","system_serial_number","chassis_asset_tag","chassis_version"]:
            tmpdata=os.popen(cmd[key]).readlines()
            if len(tmpdata) < 1:

                tdata2[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata2[key]="N/A"
            else:
                tdata2[key]=tmpdata[0].strip()

        cmd={"compare_result":compare_result}
        tdata3={}
        for key in ["compare_result"]:
            tmpdata=os.popen(cmd[key]).readlines()
            if len(tmpdata) < 1:

                tdata3[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata3[key]="N/A"
            else:
                tdata3[key]=tmpdata[0].strip()

            a_dict = {"fru":tdata,"dmidecode":tdata2,"compare_result":tdata3}


        #dictMerged1=dict(tdata.items()+tdata2.items())


        return a_dict

    def get_BMC_Sdr_print_response_time(self,filename="BMC_Sdr_print_response_time.log"):

        Time="cat "+os.path.join(self.logpath,filename)+" |grep 'real'|awk '{print $2}'|awk -F . '{print $2}'"
        Sel_count="cat "+os.path.join(self.logpath,filename)+" | grep 'Sdr Count' | awk -F \ ':' '{print $2}'"

        cmd={"Time":Time,"Count":Sel_count}
        tdata={}

        for key in ["Time","Count"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_Sel_print_response_time(self,filename="BMC_Sel_print_response_time.log"):

        Time="cat "+os.path.join(self.logpath,filename)+" |grep 'real'|awk '{print $2}'|awk -F . '{print $2}'"
        Sel_count="cat "+os.path.join(self.logpath,filename)+" | grep 'Sel Count' | awk -F \ ':' '{print $2}'"

        cmd={"Time":Time,"Count":Sel_count}
        tdata={}

        for key in ["Time","Count"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_Sensor_air_flow(self,filename="BMC_Sensor_air_flow.log"):

        air_flow="cat "+os.path.join(self.logpath,filename)+" | grep 'ME_air_flow' | awk -F ':[ ]+' '{print $2}'"


        cmd={"air_flow":air_flow}
        tdata={}

        for key in ["air_flow"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_User_add_local(self,filename="BMC_User_add_local.log"):

        username="cat "+os.path.join(self.logpath,filename)+" | grep 'Alibaba' | awk -F\ '[ ]+' '{print $2}'"

        cmd={"username":username}
        tdata={}

        for key in ["username"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_User_check_local(self,filename="BMC_User_check_local.log"):

        User_Priv="cat "+os.path.join(self.logpath,filename)+" | grep 'taobao' | awk -F '[ ]+' '{print $6}'"


        cmd={"Privilege":User_Priv}
        tdata={}

        for key in ["Privilege"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_User_check_remote(self,filename="BMC_User_check_remote.log"):

        User_Priv="cat "+os.path.join(self.logpath,filename)+" | grep 'taobao' | awk -F '[ ]+' '{print $6}'"


        cmd={"Privilege":User_Priv}
        tdata={}

        for key in ["Privilege"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata


    def get_BIOS_Revision_check(self,filename="BIOS_Revision_check.log"):

        BIOS_FW="cat "+os.path.join(self.logpath,filename)+" | grep 'BIOS version' | awk -F\ ':[ ]+' '{print $2}'"

        cmd={"bios_revision":BIOS_FW}
        tdata={}

        for key in ["bios_revision"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata

    def get_BMC_Revision_check(self,filename="BMC_Revision_check.log"):

        BMC_FW="cat "+os.path.join(self.logpath,filename)+" | grep 'Firmware Revision' | awk -F\ ':[ ]+' '{print $2}'"

        cmd={"firmware_revision":BMC_FW}
        tdata={}

        for key in ["firmware_revision"]:

            tmpdata=os.popen(cmd[key]).readlines()

            if len(tmpdata) < 1:

                tdata[key]="N/A"
            elif tmpdata[0].strip() == "" or tmpdata[0].strip()==None:
                tdata[key]="N/A"

            else:

                tdata[key]=tmpdata[0].strip()

        return tdata



if __name__ == "__main__":
    parser=BMC_parser("test/bmc")

    data=parser.get_BMC_Sensor_CPU0_Power()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_CPU0_Temp()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_CPU1_Power()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_CPU1_Temp()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_DIMMG0_Power()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_DIMMG0_Temp()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_DIMMG1_Power()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_DIMMG1_Temp()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_FAN_0()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_FAN_1()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_FAN_2()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_FAN_3()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_FAN_4()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_FAN_5()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_FAN_6()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_FAN_7()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result
    data=parser.get_BMC_Sensor_Inlet_Temp()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_Outlet_Temp()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_PSU0_Power()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_PSU1_Power()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_SYS_12V()
    result = json.dumps(data,indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_Total_Power()
    result = json.dumps(data,indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Chennel_1_check_local()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Chennel_6_check_local()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Communication_local()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Communication_remote()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_CPU_utilization()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Fru_print_response_time()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_FW_Update_Downgrade()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Lan_print_response_time()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Remote_local_Fru()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sdr_print_response_time()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sel_print_response_time()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Sensor_air_flow()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_User_add_local()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_User_check_local()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_User_check_remote()
    result = json.dumps(data, indent=4)
    print '"tcresult":',result

    data=parser.get_BIOS_Revision_check()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result

    data=parser.get_BMC_Revision_check()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"tcresult":',result
