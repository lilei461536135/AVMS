#!/usr/bin/python
# -*- coding: UTF-8 -*-

from db_baseline_base import db_baseline_base
from graph_base import graph_base

class Pi_base(db_baseline_base):
    def __init__(self, user_id,dbname=None):
        self.user_id = user_id
        db_baseline_base.__init__(self, 'CPU_Pi', self.user_id,dbname)
        self.init_pi()
        self.set_test_command()

    def init_pi(self):
        if db_baseline_base.getSubMetric(self, "CPU_Pi") == None:
            pi_graph = graph_base("CPU PI score", "PI", [], "PI", "CPU PI", {}, {});
            db_baseline_base.addSubMetric(self, "CPU_Pi", pi_graph.data);

    def addRecords(self,tcresult,sample):
        self.addRecord("CPU_Pi",sample,tcresult["0"])


    def set_test_command(self, command="./pi.sh &> pi.result"):
        if self.data["test_command"] == None:
            self.data["test_command"] = command


