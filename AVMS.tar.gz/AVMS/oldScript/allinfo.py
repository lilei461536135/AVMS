import sysinfo
import os
import sys
import json
import time
import commands

dirTest = '/tmp/tools'

def collectBMC():
    '''collect the BMC info'''
    path = dirTest + '/shell'
    os.chdir(path)
    cmdRt = os.system('./collectBMCinfo.sh')
    if cmdRt == 0 :
        print 'collect BMC info is ok.'
    else:
        print 'collect BMC info is error.'
        sys.exit()

def collectNetwork():
    '''collect the Network info'''
    path = dirTest + '/shell'
    os.chdir(path)
    cmdRt = os.system('./collectNetwork.sh')
    if cmdRt == 0:
        print 'collect Network is ok.'
    else:
        print 'collect Network is error.'
        sys.exit(-1)

def collectBIOS():
    '''collect the OS info'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    cmd = 'dmidecode -t bios | grep -i Vendor'
    (cmdRt, result) = commands.getstatusoutput(cmd)
    print "cmdRt : " , cmdRt
    if cmdRt == 0:
        print cmd + ' is ok.'
        vendor_all = result.split(':')
        print "vendor_all : " , vendor_all
        vendor = vendor_all[1].strip()
        print 'vendor : ' , vendor
        if vendor == 'American Megatrends Inc.' : 
            print 'The vendor is American Megatrends Inc.'
            cmdRt = os.system('./SCELNX_64 /o /s ' + 'BIOS_info_' + now)
            if cmdRt == 0:
                print 'collect BIOS is ok.'
            else:
                print 'collect BIOS is error.'
                sys.exit(-1)
        else :
            print 'The vendor is not American Megatrends Inc.'
    else:
        print cmd + ' is error!'
        sys.exit(-1)

def collectCPU():
    '''collect the CPU info'''
    path = dirTest + '/shell'
    os.chdir(path)
    info = sysinfo.info('cpu')
    json_str = json.dumps(info, indent=1)
    print json_str
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    with open('CPU_info_' + now, 'w') as f:
        f.write(json_str)
        f.close()

def collectMEMSUMMARY():
    '''collect the MEMSUMMARY info'''
    path = dirTest + '/shell'
    os.chdir(path)
    info = sysinfo.info('mem')
    json_str = json.dumps(info, indent=1)
    print json_str
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    with open('MEMSUMMARY_info_' + now, 'w') as f:
        f.write(json_str)
        f.close()

def collectMEM_dimms():
    '''collect the MEMSUMMARY info'''
    path = dirTest + '/shell'
    os.chdir(path)
    info = sysinfo.info('memlocation')
    json_str = json.dumps(info, indent=1)
    print json_str
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    with open('MEM_dimms_info_' + now, 'w') as f:
        f.write(json_str)
        f.close()

def collectstorage():
    '''collect the MEMSUMMARY info'''
    path = dirTest + '/shell'
    os.chdir(path)
    info = sysinfo.info('storage')
    json_str = json.dumps(info, indent=1)
    print json_str
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    with open('storage_info_' + now, 'w') as f:
        f.write(json_str)
        f.close()

def collect_os_dmesg_info():
    '''collect the dmesg info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'OS_dmesg_' + now
    cmd = 'dmesg > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect dmesg is ok.'
    else:
        print 'collect dmesg is error.'
        sys.exit(-1)

def collect_os_message_info():
    '''collect the message info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'OS_message_' + now
    cmd = 'cat /var/log/messages > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect message is ok.'
    else:
        print 'collect message is error.'
        sys.exit(-1)

def collect_os_interrupts_info():
    '''collect the interrupts info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'OS_interrupts_' + now
    cmd = 'cat /proc/interrupts > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect interrupts is ok.'
    else:
        print 'collect interrupts is error.'
        sys.exit(-1)

def collect_os_cpuinfo_info():
    '''collect the interrupts info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'OS_cpuinfo_' + now
    cmd = 'cat /proc/cpuinfo > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect cpuinfo is ok.'
    else:
        print 'collect cpuinfo is error.'
        sys.exit(-1)

def collect_os_meminfo_info():
    '''collect the meminfo info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'OS_meminfo_' + now
    cmd = 'cat /proc/meminfo > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect meminfo is ok.'
    else:
        print 'collect meminfo is error.'
        sys.exit(-1)

def collect_os_freeG_info():
    '''collect the freeG info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'OS_freeG_' + now
    cmd = 'free -g > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect free -g is ok.'
    else:
        print 'collect free -g is error.'
        sys.exit(-1)

def collect_os_lsscsi_info():
    '''collect the lsscsi info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'OS_lsscsi_' + now
    cmd = 'lsscsi -v > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect lsscsi -v is ok.'
    else:
        print 'collect lsscsi -v is error.'
        sys.exit(-1)

def collect_os_lspci_info():
    '''collect the lspci info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'OS_lspci_' + now
    cmd = 'lspci -vvvv -t > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect lspci -vvvv -t is ok.'
    else:
        print 'collect lspci -vvvv -t is error.'
        sys.exit(-1)


def collect_os_ps_info():
    '''collect the ps info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'OS_ps_' + now
    cmd = 'ps -ef > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect ps -ef is ok.'
    else:
        print 'collect ps -ef is error.'
        sys.exit(-1)

def collect_BIOS_sum_info():
    '''collect the BIOS sum info.'''
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    name = 'BIOS_sum_' + now
    cmd = 'dmidecode -t bios > ' + name 
    cmdRt = os.system(cmd)
    if cmdRt == 0:
        print 'collect dmidecode -t bios is ok.'
    else:
        print 'collect dmidecode -t bios is error.'
        sys.exit(-1)

def collect_tsar_info(n):
    '''collect the tsar info'''
    tsar_array = ['cpu', 'io', 'mem', 'tcp', 'udp', 'traffic'];
    path = dirTest + '/shell'
    os.chdir(path)
    now = time.strftime('%Y_%m_%d_%H_%M_%S')
    for i in tsar_array:
        print "i : " ,i 
        cmd = 'tsar --' + i + ' -n ' + str(n) + ' > TSAR_' + i + '_' + now
        print cmd 
        cmdRt = os.system(cmd)
        if cmdRt == 0 :
            print cmd + ' is ok!'
        else:
            print cmd + ' is error!'
            sys.exit(-1)

    print 'collect_tsar_info is ok!'

def collect_log():
    '''collect the log'''
    path = dirTest + '/shell'
    os.chdir(path)
    cmd = "dmidecode -t 1 | grep 'Serial Number' | awk '{print $NF}'"
    print "cmd : ", cmd
    (cmdRt, sn) = commands.getstatusoutput(cmd)
    print cmdRt, sn
    with open(dirTest + '/name', 'r') as f:
        path = f.readline()
        cmd = 'mkdir -p ' + path + '/' + sn
        print cmd 
        cmdRt = os.system(cmd)
        if cmdRt == 0:
            print cmd + ' is ok'
        else:
            print cmd + ' is error'
            sys.exit(-1)
        cmd = 'mv BMC* BIOS* CPU* MEM* Network* OS* storage* TSAR* ' + path + '/' + sn
        print cmd 
        cmdRt = os.system(cmd)
        if cmdRt == 0:
            print cmd + ' is ok'
        else:
            print cmd + ' is error'
            sys.exit(-1)
        f.close()



def before_collect():
    collectBMC()
    collectNetwork()
    collectBIOS()
    collectCPU()
    collectMEM_dimms()
    collectMEMSUMMARY()
    collectstorage()
    collect_os_dmesg_info()
    collect_os_message_info()
    collect_os_ps_info()
    collect_os_lspci_info()
    collect_os_lsscsi_info()
    collect_os_cpuinfo_info()
    collect_os_meminfo_info()
    collect_os_interrupts_info()
    collect_BIOS_sum_info()
    collect_os_freeG_info()


def end_collect():
    collectBMC()
    collectNetwork()
    collectBIOS()
    collectCPU()
    collectMEM_dimms()
    collectMEMSUMMARY()
    collectstorage()
    collect_os_dmesg_info()
    collect_os_message_info()
    collect_os_ps_info()
    collect_os_lspci_info()
    collect_os_lsscsi_info()
    collect_os_cpuinfo_info()
    collect_os_meminfo_info()
    collect_os_interrupts_info()
    collect_BIOS_sum_info()
    collect_os_freeG_info()
    collect_tsar_info(2)





if __name__ == "__main__":
    if len(sys.argv) == 2:
        print sys.argv[1]
        if sys.argv[1] == 'before':
            ## chmod the bash shell 
            cmd = 'chmod u+x *'
            path = dirTest + '/shell'
            os.chdir(path)
            cmdRt = os.system(cmd)
            if cmdRt == 0:
                print cmd + ' is ok'
            else :
                print cmd + ' is error.'
                sys.exit(-1)
            ####################
            before_collect()
        elif sys.argv[1] == 'end':
            end_collect()
            collect_log()
        else:
            print sys.argv[1] + ' is error!'
            print 'before or end.'
            sys.exit(-1)
    else:
        print 'must input a before or end.'
        sys.exit(-1)
