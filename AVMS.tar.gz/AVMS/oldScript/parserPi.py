#!/usr/bin/python
# -*- coding: UTF-8 -*-

from db_report_base import db_report_base

class parserPi(db_report_base):
    def __init__(self, number, SN, dev_mode, tags, IP, filename, user_id):
        tcresult = self.parser(filename)
        db_report_base.__init__(self, number, SN, "CPU", dev_mode, tags, "CPU_pi", tcresult, IP, user_id, "performance")
        db_report_base.insert2reportdb(self)

    def parser(self, filename):
        #print 'pi parser function.'
        tcresult = dict()
        with open(filename) as fp :
            while 1 :
                line = fp.readline()
                if not line:
                    break
                #print line
                line = line.strip('\n')
                scoreArr = line.split(':')
                #print "scoreArr : " , scoreArr
                tcresult[scoreArr[0]] = scoreArr[1]

        return tcresult


if __name__ == "__main__":
    pp = parserPi("1111", "2222", "3333", "4444", "5555", "6666", "7777", "pi.result")
    print "pp.data : ", pp.data
