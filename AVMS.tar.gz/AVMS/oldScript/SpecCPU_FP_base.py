import os
import sys
import re
from db_baseline_base import db_baseline_base
from graph_base import graph_base
from pymongo import MongoClient

class SpecCPU_FP_base(db_baseline_base):
    def __init__(self, user_id,dbname=None):
        self.user_id = user_id
        db_baseline_base.__init__(self,"CPU_specFP_rate", self.user_id,dbname)
        self.init_rate_peek()
        self.init_rate_base()
        self.set_test_command()



    def init_rate_peek(self):

        if db_baseline_base.getSubMetric(self,"FP_Rate_Peek_total") == None :
            rate_peek_graph=graph_base("SPECfp@2006","FP_Rate_Peek_total",[],"SpecCPU FP_Rate_Peek_total","SpecCPU FP Rate",{},{})
            db_baseline_base.addSubMetric(self,"FP_Rate_Peek_total",rate_peek_graph.data)

    def init_rate_base(self):
        if db_baseline_base.getSubMetric(self,"FP_Rate_Base_total") == None :
            rate_base_graph=graph_base("SPECfp_base2006","FP_Rate_Base_total",[],"SpecCPU FP_Rate_Base_total","SpecCPU FP Rate",{},{})
            db_baseline_base.addSubMetric(self,"FP_Rate_Base_total",rate_base_graph.data)

    def set_test_command(self,command="sh new.reportable-avx-smt-on-rate.sh"):
        if self.data["test_command"]== None or self.data["test_command"]!="sh new.reportable-avx-smt-on-rate.sh":
            self.data["test_command"]=command


    def addRecords(self,tcresut,sample):
        self.addRecord("FP_Rate_Peek_total",sample,tcresut["FP_Rate_Peek_total"])
        self.addRecord("FP_Rate_Base_total",sample,tcresut["FP_Rate_Base_total"])



if __name__ == "__main__":
    cpu_fp=SpecCPU_FP_base()
    cpu_fp.updateRecord2DB()
    print cpu_fp.collection.find()[0]