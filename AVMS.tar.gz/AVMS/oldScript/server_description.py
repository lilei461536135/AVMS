import os
import sys
import re
from pymongo import MongoClient
import json
import get_json
#import get_version
from fstack.utils.baseconfig import base_config

class server_description(object):
    def __init__(self,path,testname, user_id):
        self.testname=testname
        self.ppath=path
        self.user_id = user_id
        self.SNpath=self.__getSN_path()
        self.initdb()
        self.data=dict()
        self.data["hardware"]={}
        self.data["Software"]={}
        self.data["server_summary"]={}
        self.data["Test tool"]={}
        self.data["user_id"] = user_id
        self.collect_description()
        print self.data
        self.insert2db()

    def initdb(self):
        #self.client=MongoClient("mongodb://10.125.6.97:27017")

        dblink = base_config.get("avmsdb", "dblink")
        self.client = MongoClient(dblink)

        self.db=self.client.serverDescription
        self.collection=self.db.serverDescription

    def collect_description(self):
        fp=self.__get_log_path(self.SNpath,"CPU_info*")
        print "cpu path :" , fp
        data=self.get_dict_from_file(fp)
        self.data["hardware"]["CPU"]=data

        fp=self.__get_log_path(self.SNpath,"MEMSUMMARY_info*")
        data=self.get_dict_from_file(fp)
        self.data["hardware"]["MEM summary"]=data

        fp=self.__get_log_path(self.SNpath,"MEM_dimms_info*")
        data=self.get_dict_from_file(fp)
        self.data["hardware"]["MEM dimms"]=data

        #find the path
        fp=self.__get_log_path(self.SNpath,"aliflash_*")
        #load the json
        data=self.get_dict_from_file(fp)
        #write to data
        self.data["hardware"]["Aliflash"]=data

        fp=self.__get_log_path(self.SNpath,"MEM_dimms_info*")
        data=self.get_dict_from_file(fp)
        self.data["hardware"]["MEM dimms"]=data

        fp=self.__get_log_path(self.SNpath, "Network_info*")
        print "Network_info :", fp
        data = get_json.process_Network(fp)
        self.data["hardware"]["Networks"] = data["Networks"]

        #add 2016/5/3
        try:
            fp=self.__get_log_path(self.SNpath, "SERVER_hardware_*")
            print "SERVER_hardware_ :", fp
            #data = get_json.process_Network(fp)
            with open(self.jsonFilePath) as fp:
                jsonVar = json.load(fp)
                fp.close()
            self.data["hardware"]["check"]["start"] = dict()
            self.data["hardware"]["check"]["start"]["server_hardware"] = jsonVar
        except Exception, e:
            print "SERVER_hardware_ start is error, may be is not the file!"
            print e

        #add 2016/5/3
        try:
            fp=self.__get_log_path(self.SNpath, "SERVER_hardware_*", -1)
            print "SERVER_hardware_ :", fp
            #data = get_json.process_Network(fp)
            with open(self.jsonFilePath) as fp:
                jsonVar = json.load(fp)
                fp.close()
            self.data["hardware"]["check"]["end"] = dict()
            self.data["hardware"]["check"]["end"]["server_hardware"] = jsonVar
        except Exception ,e :
            print "SERVER_hardware_ end is error , maybe is not the file!"
            print e

        #add 2016/5/3
        try:
            fp=self.__get_log_path(self.SNpath, "SYSLOG_server_*")
            print "SERVER_hardware_ :", fp
            #data = get_json.process_Network(fp)
            with open(self.jsonFilePath) as fp:
                jsonVar = json.load(fp)
                fp.close()
            #self.data["hardware"]["check"]["end"] = dict()
            self.data["hardware"]["check"]["start"]["syslog_server"] = jsonVar
        except Exception, e:
            print "SYSLOG_server_ start is error , maybe is not the file!"
            print e

        #add 2016/5/3
        try:
            fp=self.__get_log_path(self.SNpath, "SYSLOG_server_*", -1)
            print "SERVER_hardware_ :", fp
            #data = get_json.process_Network(fp)
            with open(self.jsonFilePath) as fp:
                jsonVar = json.load(fp)
                fp.close()
            #self.data["hardware"]["check"]["start"] = dict()
            self.data["hardware"]["check"]["end"]["syslog_server"] = jsonVar
        except Exception, e:
            print "SYSLOG_server_ end is error , maybe is not the file!"
            print e



        fp=self.__get_log_path(self.SNpath, "BMC_info_*")
        data = get_json.process_bmc(fp)
        self.data["Software"]["BMC"] = data["BMC"]

        fp=self.__get_log_path(self.SNpath, "BIOS_sum_*")
        data = get_json.process_bios(fp)
        self.data["Software"]["BIOS"] = data["BIOS"]

        fp=self.__get_log_path(self.SNpath, "clone_info")
        data = self.get_dict_from_file(fp)
        self.data["Software"]["OS"] = data

        #data = get_version.getDictMD5ForTools("/tmp/tools")
        #self.data["Test tool"] = data

        print "BMS,FRU:", self.data["Software"]["BMC"]["FRU"]
        self.data["server_summary"]["Serial Number"] = self.data["Software"]["OS"]["sn"].split()[0]
        self.data["server_summary"]["Product Name"] = self.data["Software"]["BMC"]["FRU"]["Product Name"]
        self.data["server_summary"]["Manufacturer"] = self.data["Software"]["BMC"]["FRU"]["Product Manufacturer"]
        self.data["server_summary"]["IP"] = self.data["Software"]["OS"]["addrs"][0]["ip"]
        self.data["server_summary"]["Vendor"] = self.data["Software"]["BIOS"]["Vendor"]
        self.data["server_summary"]["ServerType"] = self.data["Software"]["BMC"]["FRU"]["Chassis Part Number"]
        self.data["server_summary"]["TestName"] = self.testname

    def insert2db(self):
        cursor = self.collection.find({"server_summary.Serial Number" : self.data["server_summary"]["Serial Number"], "server_summary.TestName": self.testname, "user_id": self.user_id})
        if cursor.count() >= 1:
            return
        else:
            self.collection.insert_one(self.data)

    def get_description(self):
        return self.data

    def __get_log_path(self,ppath,filename, pos=0):
        cmd="ls  " + ppath + " | grep " + filename
        #+os.path.join(os.path.abspath(ppath),filename)
        '''print cmd
        print os.popen(cmd).readlines()[-1]
        print os.popen(cmd).readlines()[0].split()
        str=os.popen(cmd).readlines()[-1].split()[-1]
        print str
        #filepath=os.path.join(ppath,str)
        return str'''
        print cmd
        print os.popen(cmd).read().strip('\n')
        result = os.popen(cmd).read().strip('\n')
        if result == None or result == '':
            return None
        result = os.path.join(ppath, result)
        print "result : ", result.split('\n')[0]
        if pos == 0:
            return result.split('\n')[0]
        else :
            return result.split('\n')[-1]

    def __getSN_path(self):
        return self.__get_log_path(self.ppath,"SN_")

    def get_dict_from_file(self,ppath):#,filename):
        #path=self.__get_log_path(ppath,filename)
        if ppath == None:
            return None
        print "get_dict_from_file : ", ppath
        with open(ppath) as fp:
            str=fp.read()
            #print "file :", str
            data=json.loads(str,encoding="utf-8")
            return data

if __name__ == "__main__":
    serverDes = server_description("/home/psl/AVMS2/src/script/T02_speccpu_power_stress_2016-01-13T12:24:01.297Z/10.218.169.151", "test_name")
