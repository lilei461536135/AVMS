import os,sys,json
from collections import defaultdict,Counter

class MEM_mon_parser(object):
    def __init__(self,logpath):
        self.logpath=logpath

    def get_mem_mon(self,filename="mem_mon.log"):

        log_test_line="cat "+os.path.join(self.logpath,filename)+" |grep -v times|grep -v CST"
        logdata = os.popen(log_test_line).readlines()

        #Put value in list
        mem_dict = defaultdict(list)
        for line in logdata:
                dict_key = line.split('=')[0].strip()
                dict_value = line.split('=')[1].strip()
                mem_dict.setdefault(dict_key,[]).append(dict_value)

        #count
        for key in mem_dict:
                value = Counter(mem_dict[key])
                mem_dict.update({key:value})

        return mem_dict

if __name__ == "__main__":
    #parser=MEM_mon_parser("/tmp/tools/log/")
    #parser=MEM_mon_parser(sys.argv[1])
    parser=MEM_mon_parser("/var/www/html/result/admin/avmslog/Zhuque_Stress_Test_2016-05-14-14:36:30/10.7.11.82/Stress_memtest")
    data=parser.get_mem_mon()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"memresult":',result