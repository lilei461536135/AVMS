# -*- coding: utf-8 -*-
import traceback
import os
import string
from ali_algor import TextAlgor
from check_model import get_db

_curr_dir = os.path.dirname(os.path.abspath(__file__))


###change for segmentation
def get_criteria_by_number_sn(number, sn, cfg_path, segment):
    if cfg_path == None:
        default_file = os.path.join(_curr_dir,"./cfg/default/ups1.txt")
        cfg = os.path.join(_curr_dir,"./cfg/%s/%s.txt"%(number.lower(), sn.lower()))
        if not os.path.exists(cfg):
            if not os.path.exists('/'.join(cfg.split('/')[:-1])):
                os.mkdir('/'.join(cfg.split('/')[:-1]))
            os.system("cp " + default_file + " " + cfg)
    else:
        cfg = cfg_path
    criteria = list()
    criteria_title = list()
    with open(cfg) as f:
        segment_name = None
        tag_name = None
        i = 0
        for line in f:
            i = i + 1
            ##def segment
            if line[0:11] == "def segment":
                print line.split()
                segment_name = line.split()[-1]
                print "find segment:", segment_name
                print "param segment:", segment
            #def tag
            if line[0:7] == "def tag":
                print line.split()
                tag_name = line.split()[-1]
                print "find tag:", tag_name

            if line[0:11] == "def end tag":
                tag_name = None

            if segment_name == None and i != 1:
                continue
            elif segment_name == segment or i == 1:
                #注释跳过
                if line.strip().startswith("#"):
                    continue
                #去掉末尾注释语句
                note_index = line.find("#")
                if note_index != -1:
                    line = line[0:note_index]

                line_split = line.split()


                if len(line_split) == len(criteria_title) !=0 and line_split[0][0:3] != "def":
                    if tag_name != None:
                        criteria_title.append("tag")
                        line_split.append(tag_name)
                        criteria.append(dict(zip(criteria_title, line_split)))
                        criteria_title.pop()
                    else :
                        criteria.append(dict(zip(criteria_title, line_split)))
                elif len(criteria_title) ==0 and len(line_split):
                    criteria_title = line_split
            else:
                continue

    return criteria


def get_checkpoint_by_criteria(context, key_chain, tag=None):
    key_chain = key_chain.replace('+', ' ')
    keys = key_chain.split(".")
    if tag != None:
        try:
            dbData = context.collection.find_one({"number": context.number, "tags.fio": {"$in": [tag]},"SN": context.sn, "user_id": context.user_id, "tcname": keys[0]})
        except Exception, e:
            print e
            print traceback.format_exc()
            print "tag != None " + context
    else :
        try:
            dbData = context.collection.find_one({"number": context.number, "SN": context.sn, "user_id": context.user_id, "tcname": keys[0]})
        except Exception, e:
            print e
            print traceback.format_exc()
            print "tag != None " + context

    #dbData = context.collection.find_one({"number": context.number, "tags.fio": {"$in": ["XX"]},"SN": context.sn, "user_id": context.user_id, "tcname": keys[0]})
    if dbData == None:
        print "find none data in db"
        return [None]
    print "dbData:", dbData
    print "keys:", keys
    tcresult = dbData[keys[1]]
    result = get_list_criteria(tcresult, ".".join(keys[2:]))
    #deal some error
    i = 0
    for item in result:
        if len(item.split()) > 1:
            result[i] = item.split()[0]
        i = i + 1
    return result


def get_list_criteria(context, key_chain):
    keys = key_chain.split(".")

    if type(context) is list:
        t=list()
        for i in context:
            t.extend(get_list_criteria(i,key_chain))
        return t
    elif type(context) is dict:
        if len(keys) ==1:
            return [(str(context.get(keys[0])).replace('_', '.'))]
        else:
            return get_list_criteria(context.get(keys[0]), ".".join(keys[1:]))


def get_db_data(number, sn, user_id):
    report = get_db(number, sn, user_id)
    return report



def check_report(report, segment, cfg_path=None):
    criteria = get_criteria_by_number_sn(report.number, report.sn, cfg_path, segment)
    result = list()
    for crit in criteria:
        try:
            if crit.has_key("tag"):
                values = get_checkpoint_by_criteria(report, crit.get("content"), crit.get("tag"))
            else :
                values = get_checkpoint_by_criteria(report, crit.get("content"))
        except Exception, e:
            print e
            print traceback.format_exc()
            print crit
            continue
        expect_val = crit.get("value")
        alg = crit.get("alg","nop")

        check_result = map(lambda x :getattr(TextAlgor, alg)(x, expect_val), values)

        ret = dict()
        ret.update(crit)
        ret.update({"values":values[0],"check":check_result[0]})
        result.append(ret)

        #print dict(zip(values,ret))

    return result



if __name__ == '__main__':
    report = get_db_data("M31_dell_2016-03-22-20:40:13", "FLSJT92", "admin")
    result = check_report(report, "/home/psl/work/AVMS2/avms_script/cfg/default/ups1.txt")
