#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import re


class graph_base(object):
    def __init__(self,YAxis_title,XAxis_title,XAxis_data,title,subtitle,reserved,data):
        self.data=dict()
        self.data["YAxis_title"]=YAxis_title
        self.data["XAxis_title"]=XAxis_title
        self.data["XAxis_data"]=XAxis_data
        self.data["subtitle"]=subtitle
        self.data["title"]=title
        self.data["reserved"]=reserved
        self.data["data"]=data


    def setvalue(self,key,value):
        self.data[key]=value


    def getvalue(self,key):
        return self.data[key]


