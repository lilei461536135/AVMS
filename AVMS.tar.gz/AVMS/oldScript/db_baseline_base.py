import os
import sys
import re
from pymongo import MongoClient
from fstack.utils.baseconfig import base_config
#extend function    bojie.hbj@alibaba-inc.com
class db_baseline_base(object):
    def __init__(self, name, user_id,dbname=None,tags=None):
        dblink = base_config.get("avmsdb", "dblink")
        self.client=MongoClient(dblink)
        perf_db_name = None
        if dbname == None or dbname == "":
            self.db=self.client[perf_db_name]
            perf_db_name = base_config.get("avmsdb", "perfdbname")
            self.collection=self.db[perf_db_name]
        else :
            newdb  = base_config.get("avmsdb", "newperfdb")
            self.db=self.client[newdb]
            if tags!= None:
                perf_db_name =   dbname+"-"+name+"-"+tags["fio_type"]
            else:
                perf_db_name =   dbname+"-"+name
            self.collection=self.db[perf_db_name]
        print "perf_db_name: ",perf_db_name
        #rawdbname = base_config.get("avmsdb", "rawdbname")

        curser=self.collection.find({"name":name, "user_id": self.user_id})
        self.data=dict()
        self.user_id = user_id
        if name != None:
            self.data=self.getrecord(name, user_id)
            if self.data==None:
                self.data=dict()
                self.data["name"]=name
                self.data["result"]=dict()
                self.data["test_command"]=None
                self.data["user_id"] = user_id



    def insert2baselinedb(self,data):
        print "insert2baselinedb."
        client = MongoClient("mongodb://10.125.6.97:27017")
        print "connect the db."
        db = client.perf10
        coll = db.perf10
        coll.insert_one(data)
        print "insert db is ok"


    def getrecord(self,key, user_id):
        """
        query db record from db
        """

        curser=self.collection.find({"name":key, "user_id": self.user_id})
        if curser.count() >= 1:
            return curser[0]
        else :
            return None

    def addSubMetric(self,metric,value):
        self.data["result"][metric]=value


    def getSubMetric(self,metric):
        if self.data["result"].has_key(metric):
            return self.data["result"][metric]
        else:
            return None

    def addRecord(self,metric,sample,value):
        if self.data["result"][metric]["data"].has_key(sample):
            print "the sample %s already exist,the add action is not allowed"%sample
        else:
            self.data["result"][metric]["data"][sample]=value

    def updateRecord2DB(self):
        name=self.data["name"]
        curser=self.collection.find({"name":name, "user_id": self.user_id})
        if curser.count() >= 1:
            result = self.collection.replace_one({"name":name, "user_id": self.user_id},self.data)
            #print "updateRecord2DB  result :",result
            #if result["updatedExisting"] != True:
            #    return {"result": "error", "log": "replace_one " + name + " is error!"}
            #else :
            return {"result": "ok"}
        else:
            self.collection.insert_one(self.data)
            return {"result" : "ok"}
