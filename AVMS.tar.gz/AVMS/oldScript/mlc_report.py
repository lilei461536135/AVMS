from db_report_base import db_report_base
import os
import re
from pymongo import MongoClient
import json


class mlc_report(db_report_base):

    def __init__(self,number, SN,dev_mode,tags,IP,filename, user_id):
        self.filename=filename
        self.user_id = user_id
        tcresult=self.parser(filename)
        self.matricname=os.path.basename(filename).split('.')[0]
        db_report_base.__init__(self,number, SN,"Memory",dev_mode,tags,"Memory_MLC",tcresult,IP, user_id, "performance")
        self.insert2reportdb()



    def parser(self,filename):
        data=dict()
        data["Memory_idle_latencies"]=self.get_latency()
        data["Memory_BW_Per_Socket"]=self.get_BW()
        data["memory_Peak_BW"]=self.get_Peak_BW()
        data["cache-to-cache_latency"]=self.get_C2C_latency()
        data["Latency_with_loads"]=self.get_Latency_with_loads()

        return data


    def get_latency(self):
        cmd='cat ' + self.filename+'|grep "Measuring idle latencies (in ns)..." -A 4'
        tdata=os.popen(cmd).readlines()
        data={}
        data["socket0-Memory0"]=tdata[3].split()[1]
        data["socket0-Memory1"]=tdata[3].split()[2]
        data["socket1-Memory0"]=tdata[4].split()[1]
        data["socket1-Memory1"]=tdata[4].split()[2]

        return data

    def get_BW(self):
        cmd='cat ' + self.filename+'|grep "Measuring Memory Bandwidths between nodes within system" -A 7'
        tdata=os.popen(cmd).readlines()
        data={}
        data["socket0-Memory0"]=tdata[6].split()[1]
        data["socket0-Memory1"]=tdata[6].split()[2]
        data["socket1-Memory0"]=tdata[7].split()[1]
        data["socket1-Memory1"]=tdata[7].split()[2]
        return data

    def get_Peak_BW(self):
        cmd='cat ' + self.filename+'|grep "Measuring Peak Memory Bandwidths for the system" -A 8'
        tdata=os.popen(cmd).readlines()
        data={}
        data["ALL Reads"]=tdata[4].split(':')[1]
        data["3:1 Reads-Writes"]=tdata[5].split(':')[2]
        data["2:1 Reads-Writes"]=tdata[6].split(':')[2]
        data["1:1 Reads-Writes"]=tdata[7].split(':')[2]
        data["Stream-triad like"]=tdata[8].split(':')[1]
        return data


    def get_C2C_latency(self):
        cmd='cat ' + self.filename+'|grep "Measuring cache-to-cache transfer latency (in ns)..." -A 2'
        tdata=os.popen(cmd).readlines()
        data={}
        data["Local socket L2->L2 HIT"]=tdata[1].split()[5]
        data["Local Socket L2->L2 HITM latency"]=tdata[2].split()[5]
        return data

    def get_Latency_with_loads(self):
        cmd='cat ' + self.filename+'|grep "==========================" -A 19'
        tdata=os.popen(cmd).readlines()
        l=list()
        for line in tdata[1:]:
            l.append(line.split())
        temp=map(list,zip(*l))
        data={}
        data["Inject delay"]=temp[0]
        data["latency"]=temp[1]
        data["Bandwith"]=temp[2]

        return data


if __name__ == "__main__":
    #tmp='{"fio version" : "fio-2.0000000","70>=0000":20}'
    #tmp1='{"aaaa":"bbbb","aaa":1111}'
    #data=json.loads(tmp,encoding="utf-8")
    #(self,number, SN,dev_mode,tags,IP,filename, user_id):
    #cpu=mlc_report("numberfio33","SN2fio33","N31_fio","N31-xxxs-fio","baselinefio","192.168.1.1","test/mlc.log", "test")
    cpu=mlc_report("numberfio33","SN2fio33","N31_fio","baselinefio","192.168.1.1","test/mlc.log", "test")
    #cpu.coll.insert_one(data)
    cpu.insert2reportdb()
