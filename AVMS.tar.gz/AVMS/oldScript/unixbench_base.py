#!/usr/bin/python
# -*- coding: UTF-8 -*-

from db_baseline_base import db_baseline_base
from graph_base import graph_base

class unixbench_base(db_baseline_base):
    def __init__(self, user_id,dbname=None):
        self.user_id = user_id
        db_baseline_base.__init__(self, "unixbench_test", self.user_id,dbname)
        self.init_Dhrystone_2_using_register_variables()
        self.init_Double_Precision_Whetstone()
        self.init_Execl_Throughput()
        self.init_File_Copy_1024_bufsize_2000_maxblocks()
        self.init_File_Copy_256_bufsize_500_maxblocks()
        self.init_File_Copy_4096_bufsize_8000_maxblocks()
        self.init_Pipe_Throughput()
        self.init_Pipe_based_Context_Switching()
        self.init_Process_Creation()
        self.init_Shell_Scripts_1_concurrent()
        self.init_Shell_Scripts_8_concurrent()
        self.init_System_Benchmarks_Index_Score()
        self.init_System_Call_Overhead()
        self.set_test_command()

    def init_Dhrystone_2_using_register_variables(self):
        if db_baseline_base.getSubMetric(self, "Dhrystone_2_using_register_variables") == None:
            Dhr_graph = graph_base("Unixbench Dhrystone score", "Dhrystone", [], "Dhrystone_2_using_register_variables", "Unixbench Dhrystone", {}, {});
            db_baseline_base.addSubMetric(self, "Dhrystone_2_using_register_variables", Dhr_graph.data);

    def init_Double_Precision_Whetstone(self):
        if db_baseline_base.getSubMetric(self, "Double_Precision_Whetstone") == None:
            Double_graph = graph_base("Unixbench init_Double_Precision_Whetstone score", "Double", [], "Double_Precision_Whetstone", "Unixbench Double", {}, {});
            db_baseline_base.addSubMetric(self, "Double_Precision_Whetstone", Double_graph.data);

    def init_Execl_Throughput(self):
        if db_baseline_base.getSubMetric(self, "Execl_Throughput") == None:
            Execl_graph = graph_base("Unixbench Execl_Throughput score", "Execl_Throughput", [], "Execl_Throughput", "Unixbench Execl_Throughput", {}, {});
            db_baseline_base.addSubMetric(self, "Execl_Throughput", Execl_graph.data);

    def init_File_Copy_1024_bufsize_2000_maxblocks(self):
        if db_baseline_base.getSubMetric(self, "File_Copy_1024_bufsize_2000_maxblocks") == None:
            File_1024_graph = graph_base("Unixbench File_Copy_1024 score", "File_Copy_1024", [], "File_Copy_1024_bufsize_2000_maxblocks", "Unixbench File_Copy_1024", {}, {});
            db_baseline_base.addSubMetric(self, "File_Copy_1024_bufsize_2000_maxblocks", File_1024_graph.data);

    def init_File_Copy_256_bufsize_500_maxblocks(self):
        if db_baseline_base.getSubMetric(self, "File_Copy_256_bufsize_500_maxblocks") == None:
            File_256_graph = graph_base("Unixbench File_Copy_256 score", "File_Copy_256", [], "File_Copy_256_bufsize_500_maxblocks", "Unixbench File_Copy_256", {}, {});
            db_baseline_base.addSubMetric(self, "File_Copy_256_bufsize_500_maxblocks", File_256_graph.data);

    def init_File_Copy_4096_bufsize_8000_maxblocks(self):
        if db_baseline_base.getSubMetric(self, "File_Copy_4096_bufsize_8000_maxblocks") == None:
            File_4096_graph = graph_base("Unixbench File_Copy_4096 score", "File_Copy_4096", [], "File_Copy_4096_bufsize_8000_maxblocks", "Unixbench File_Copy_4096", {}, {});
            db_baseline_base.addSubMetric(self, "File_Copy_4096_bufsize_8000_maxblocks", File_4096_graph.data);

    def init_Pipe_Throughput(self):
        if db_baseline_base.getSubMetric(self, "Pipe_Throughput") == None:
            Pipe_graph = graph_base("Unixbench Pipe_Throughput score", "Pipe_Throughput", [], "Pipe_Throughput", "Unixbench Pipe_Throughput", {}, {});
            db_baseline_base.addSubMetric(self, "Pipe_Throughput", Pipe_graph.data);

    def init_Pipe_based_Context_Switching(self):
        if db_baseline_base.getSubMetric(self, "Pipe_based_Context_Switching") == None:
            Pipe_sw_graph = graph_base("Unixbench Pipe_based score", "Pipe_based", [], "Pipe_based_Context_Switching", "Unixbench Pipe_based", {}, {});
            db_baseline_base.addSubMetric(self, "Pipe_based_Context_Switching", Pipe_sw_graph.data);

    def init_Process_Creation(self):
        if db_baseline_base.getSubMetric(self, "Process_Creation") == None:
            Pro_graph = graph_base("Unixbench Process_Creation score", "Process_Creation", [], "Process_Creation", "Unixbench Process_Creation", {}, {});
            db_baseline_base.addSubMetric(self, "Process_Creation", Pro_graph.data);

    def init_Shell_Scripts_1_concurrent(self):
        if db_baseline_base.getSubMetric(self, "Shell_Scripts_1_concurrent") == None:
            Shell_graph = graph_base("Unixbench Shell_Scripts_1 score", "Shell_Scripts_1", [], "Shell_Scripts_1_concurrent", "Unixbench Shell_Scripts_1", {}, {});
            db_baseline_base.addSubMetric(self, "Shell_Scripts_1_concurrent", Shell_graph.data);

    def init_Shell_Scripts_8_concurrent(self):
        if db_baseline_base.getSubMetric(self, "Shell_Scripts_8_concurrent") == None:
            Shell_8_graph = graph_base("Unixbench Shell_Scripts_8 Score", "Shell_Scripts_8", [], "Shell_Scripts_8_concurrent", "Unixbench Shell_Scripts_8", {}, {});
            db_baseline_base.addSubMetric(self, "Shell_Scripts_8_concurrent", Shell_8_graph.data);

    def init_System_Call_Overhead(self):
        if db_baseline_base.getSubMetric(self, "System_Call_Overhead") == None:
            System_graph = graph_base("Unixbench System_Call_Overhead Score", "System_Call_Overhead", [], "System_Call_Overhead", "Unixbench System_Call_Overhead", {}, {});
            db_baseline_base.addSubMetric(self, "System_Call_Overhead", System_graph.data);

    def init_System_Benchmarks_Index_Score(self):
        if db_baseline_base.getSubMetric(self, "System_Benchmarks_Index_Score") == None:
            Sys_index_graph = graph_base("Unixbench System_Benchmarks_Index Score", "System_Benchmarks_Index", [], "System_Benchmarks_Index_Score", "Unixbench System_Benchmarks_Index", {}, {});
            db_baseline_base.addSubMetric(self, "System_Benchmarks_Index_Score", Sys_index_graph.data);


    def addRecords(self,tcresult,sample):
        self.addRecord("Dhrystone_2_using_register_variables",sample,tcresult["Dhrystone 2 using register variables"]["Index"])
        self.addRecord("System_Call_Overhead",sample,tcresult["System Call Overhead"]["Index"])
        self.addRecord("Shell_Scripts_8_concurrent",sample,tcresult["Shell Scripts (8 concurrent)"]["Index"])
        self.addRecord("Shell_Scripts_1_concurrent",sample,tcresult["Shell Scripts (1 concurrent)"]["Index"])
        self.addRecord("Process_Creation",sample,tcresult["Process Creation"]["Index"])
        self.addRecord("Pipe_based_Context_Switching",sample,tcresult["Pipe-based Context Switching"]["Index"])
        self.addRecord("Pipe_Throughput",sample,tcresult["Pipe Throughput"]["Index"])
        self.addRecord("File_Copy_4096_bufsize_8000_maxblocks",sample,tcresult["File Copy 4096 bufsize 8000 maxblocks"]["Index"])
        self.addRecord("File_Copy_256_bufsize_500_maxblocks",sample,tcresult["File Copy 256 bufsize 500 maxblocks"]["Index"])
        self.addRecord("File_Copy_1024_bufsize_2000_maxblocks",sample,tcresult["File Copy 1024 bufsize 2000 maxblocks"]["Index"])
        self.addRecord("Execl_Throughput",sample,tcresult["Execl Throughput"]["Index"])
        self.addRecord("Double_Precision_Whetstone",sample,tcresult["Double-Precision Whetstone"]["Index"])
        self.addRecord("System_Benchmarks_Index_Score",sample,tcresult["System Benchmarks Index Score:"])


    def set_test_command(self, command="./Run -c 1 -c cpuNumber"):
        if self.data["test_command"] == None :
            self.data["test_command"] = command
