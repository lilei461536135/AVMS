#!/usr/bin/python
# -*- coding: UTF-8 -*-

from db_report_base import db_report_base
from bs4 import BeautifulSoup

class UnixBench_report(db_report_base):
    def __init__(self, number, SN, dev_mode, tags, IP, filename, user_id):
        print 'parserUnixBench __init__ function.'
        tcresult = self.parser(filename)
        db_report_base.__init__(self, number, SN, "system", dev_mode, tags, "System_unixbench", tcresult, IP, user_id, "performance")
        db_report_base.insert2reportdb(self)


    def parser(self, filename):
        print 'db_report_base parser function.'
        tcresult = dict();
        with open(filename) as fp:
            soup = BeautifulSoup(fp)
            #print soup.h3
            print soup.find_all("h3")[1]
            #print soup.find_all("tbody")[1].children
            tcresult["Benchmark Run"] = soup.find_all("h3")[1].string
            #tcresult["time"] = soup.find_all("p")[5].string
            #tcresult["time"] = soup.find_all("p")[3].string
            tcresult["time"] = soup.find_all("p")[3].string


            '''#print soup.find_all("tbody")[1]
            soup = soup.find_all("table")[1]
            print soup
            #soup = soup.find_all("tbody")[1]'''
            #print soup.find_all("tbody")
            #soup = soup.find_all("tbody")
            soup = soup.find_all("table")[1]


            print soup.find_all("tr")[1]
            for i in range(1,13):
                node_tr = soup.find_all("tr")[i]
                print node_tr
                name = node_tr.b.string
                print node_tr.find_all("tt")[0].string
                tcresult[name] = dict()
                tcresult[name]["Score"] = node_tr.find_all("tt")[0].string
                tcresult[name]["Unit"] = node_tr.find_all("tt")[1].string
                tcresult[name]["Time"] = node_tr.find_all("tt")[2].string
                tcresult[name]["Iters"] = node_tr.find_all("tt")[3].string
                tcresult[name]["Baseline"] = node_tr.find_all("tt")[4].string
                tcresult[name]["Index"] = node_tr.find_all("tt")[5].string
                print tcresult[name]
            node_tr_last = soup.find_all("tr")[13]
            last_score = node_tr_last.find_all("b")[0].string
            print node_tr_last.find_all("b")[1].tt.string
            tcresult[last_score] = node_tr_last.find_all("b")[1].tt.string
            print "tcresult : ", tcresult
            return tcresult


if __name__ == "__main__":
    pu = parserUnixBench("1111", "2222", "3333", "4444", "5555", "6666", "7777", "tb2b05533.sqa.tbc-2016-02-23-01.html")
