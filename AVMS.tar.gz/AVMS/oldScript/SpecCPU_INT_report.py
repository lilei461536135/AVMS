from db_report_base import db_report_base
import os
import re
from pymongo import MongoClient

class SpecCPU_INT_report(db_report_base):

    def __init__(self,number, SN,dev_mode,tags,IP,filename, user_id, category="performance"):
        tcresult=self.parser(filename)
        db_report_base.__init__(self,number, SN,"CPU",dev_mode,tags,"CPU_SpecINT_rate",tcresult,IP, user_id, category)
        self.insert2reportdb()



    def parser(self,filename):
        data=dict()
        cmd='awk "/==============================================================================/{n=12;next}--n>=0" '+filename
        cmd1='grep "SPECint(R)_rate_base2006" '+filename
        #cmd1='"'+"grep 'Est. SPECint(R)_rate_base2006' "+path +'"'
        #cmd2='grep "Est. SPECint_rate2006" '+filename
        # change for 3time speccpu
        cmd2 = 'grep "SPECint_rate2006" ' + filename

        #cmd2='"'+"grep 'Est. SPECint_rate2006' "+path +'"'
        basetotal=re.split(r'\s+',os.popen(cmd1).read().strip())[-1]
        peektotal=re.split(r'\s+',os.popen(cmd2).read().strip())[-1]
        data["INT_Rate_Base_total"]=basetotal
        data["INT_Rate_Peek_total"]=peektotal

        str=os.popen(cmd)

        for line in str.readlines():
            splitdata=re.split(r'\s+',line)
            tmp=dict()
            tmp["Base_Run_time"]=splitdata[2]
            tmp["Base_Rate"]=splitdata[3]
            tmp["Peek_Run_time"]=splitdata[6]
            tmp["Peek_Rate"]=splitdata[7]
            data[splitdata[0].replace('.','_')]=tmp

        return data

if __name__ == "__main__":
    cpu=SpecCPU_INT_report("number112233int","SN223333int","N31int","N31-xxxsint","baseline","192.168.1.1","\/Users\/maxuhua\/Desktop\/CINT2006.001.int.txt")
    cpu.insert2reportdb()
