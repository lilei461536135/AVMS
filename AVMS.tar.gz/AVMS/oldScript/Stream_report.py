from db_report_base import db_report_base
import os
import re
from pymongo import MongoClient

class Stream_report(db_report_base):

    def __init__(self,number, SN,dev_mode,tags,IP,filename, user_id):
        tcresult=self.parser(filename)
        db_report_base.__init__(self,number, SN,"MEM",dev_mode,tags,"Mem_Stream_Bandwidth",tcresult,IP, user_id, "performance")
        self.insert2reportdb()


    def parser(self,filename):
        data=dict()
        cmd='awk "/Function,Rate \(MB\/s\),Avg time,Min time,Max time/{n=4;next}--n>=0" '+filename
        str=os.popen(cmd)
        for line in str.readlines():
            tmpdict=dict()
            splitdata=re.split(r'[\s\,\:]+',line)
            tmpdict["bandwith"]=splitdata[1]
            tmpdict["Avg time"]=splitdata[2]
            tmpdict["Min tine"]=splitdata[3]
            tmpdict["Max time"]=splitdata[4]
            data[splitdata[0]]=tmpdict
        return data


if __name__ == '__main__':
    mem=Stream_report("number112233mem","SN22333mem","N31mem","N31-xxxsmem","baseline","192.168.1.1","\/Users\/maxuhua\/Desktop\/stream.result.txt")
    mem.insert2reportdb()
