from db_baseline_base import db_baseline_base
from graph_base import graph_base

class qperf_base(db_baseline_base):
    def __init__(self,tcname, user_id,dbname=None):
        self.matricname=tcname
        self.user_id = user_id
        db_baseline_base.__init__(self, self.matricname, self.user_id,dbname)
        self.init_tcp_bw()
        self.init_tcp_lat()
        self.set_test_command()

    def init_tcp_bw(self):
        if db_baseline_base.getSubMetric(self, "bandwidth") == None:
            tcp_bw_graph = graph_base("MB/sec", "bytes", [1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536], self.matricname, "title", {}, {})
            db_baseline_base.addSubMetric(self, "bandwidth", tcp_bw_graph.data)

    def init_tcp_lat(self):
        if db_baseline_base.getSubMetric(self, "latency") == None:
            tcp_lat_graph = graph_base("us", "K/sec", [1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536], self.matricname, "title", {}, {})
            db_baseline_base.addSubMetric(self, "latency", tcp_lat_graph.data)


    def addRecords(self,tcresult,sample):
        if self.matricname.find("bw")>=0:
            if self.matricname.find("udp")>=0:
                key="send_bw"
            else:
                key="bw"
            self.addRecord("bandwidth",sample,self.get_sorted_list_value(tcresult,key))
        elif self.matricname.find("lat")>=0:
            self.addRecord("latency",sample,self.get_sorted_list_value(tcresult,"latency"))
        else:
            print "invalid tcname"

    def get_sorted_list_value(self,data,vkey):
        ldata=[]
        print "data: ",data
        dataKey = data.keys()
        keys = []
        for i in dataKey:
            if i != 'cmd':
                keys.append(i)
        #l=sorted(data.keys(),key=int)
        l=sorted(keys,key=int)
        for key in l:
            ldata.append(data[key][vkey])
        return ldata


    def set_test_command(self, command="qperf tcp_bw tcp_lat udp_bw udp_lat"):
        if self.data["test_command"] == None or self.data["test_command"] != "qperf tcp_bw tcp_lat udp_bw udp_lat":
            self.data["test_command"] = command
