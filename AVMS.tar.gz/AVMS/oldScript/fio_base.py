import os
import sys
import re
from db_baseline_base import db_baseline_base
from graph_base import graph_base
from pymongo import MongoClient

class fio_base(db_baseline_base):
    def __init__(self,filename, user_id,dbname=None,tags=None):
        self.user_id = user_id
        self.metricname=filename
        db_baseline_base.__init__(self,self.metricname, self.user_id,dbname,tags)
        self.init_fio_BW()
        self.init_fio_iops()
        self.init_fio_avg_latency()
        self.init_fio_lat_distribution()
        self.set_test_command()



    def init_fio_BW(self):
        if db_baseline_base.getSubMetric(self,"IO_Bandwidth") == None :
            graph=graph_base("Bandwidth (MB/s)","Block size",[],self.metricname,"IO Bandwidth",{},{})
            db_baseline_base.addSubMetric(self,"IO_Bandwidth",graph.data)
    def init_fio_iops(self):
        if db_baseline_base.getSubMetric(self,"IO_IOPS") == None :
            graph=graph_base("Rate (op/s)","Block size",[],self.metricname,"IOPS",{},{})
            db_baseline_base.addSubMetric(self,"IO_IOPS",graph.data)
    def init_fio_avg_latency(self):
        if db_baseline_base.getSubMetric(self,"IO_Avg_latency") == None :
            graph=graph_base("latency (ms)","Block size",[],self.metricname,"IO_Avg_latency",{},{})
            db_baseline_base.addSubMetric(self,"IO_Avg_latency",graph.data)
    def init_fio_lat_distribution(self):
        if db_baseline_base.getSubMetric(self,"IO_Lat_Distribution") == None :
            graph=graph_base("latency (ms)","percent %",["0%", "1%","5%","10%","20%","30%","40%","50%","60%","70%","80%","90%","95%","99%","99.5%","99.9%", "99.95%", "99.99%"],self.metricname,"IO_Lat_Distribution",{},{})
            db_baseline_base.addSubMetric(self,"IO_Lat_Distribution",graph.data)

    def addRecords(self,tcresult,sample):
        self.addRecord("IO_Bandwidth",sample,self.get_IO_Bandwidth(tcresult))
        self.addRecord("IO_IOPS",sample,self.get_IO_IOPS(tcresult))
        self.addRecord("IO_Avg_latency",sample,self.get_IO_Avg_latency(tcresult))
        self.addRecord("IO_Lat_Distribution",sample,self.get_lat_dictribution(tcresult))


    def get_IO_Bandwidth(self,tcresult):
        data=dict()
        data["Read_Bandwidth"]=tcresult["jobs"][0]["read"]["bw_mean"]
        data["Write_Bandwidth"]=tcresult["jobs"][0]["write"]["bw_mean"]
        return data

    def get_IO_IOPS(self,tcresult):
        data=dict()
        data["Read_IOPS"]=tcresult["jobs"][0]["read"]["iops"]
        data["Write_IOPS"]=tcresult["jobs"][0]["write"]["iops"]
        return data

    def get_IO_Avg_latency(self,tcresult):
        data=dict()
        data["Read_Avg_latency"]=tcresult["jobs"][0]["read"]["lat"]["mean"]
        data["Write_Avg_latency"]=tcresult["jobs"][0]["write"]["lat"]["mean"]
        return data
    def get_lat_dictribution(self,tcresult):
        data=dict()
        data["Read_Lat_distribution"]=self.get_sorted_list_value(tcresult["jobs"][0]["read"]["clat"]["percentile"])
        data["Write_Lat_Distribution"]=self.get_sorted_list_value(tcresult["jobs"][0]["write"]["clat"]["percentile"])
        return data

    def set_test_command(self,command="sh fio_test.sh"):
        if self.data["test_command"]== None or self.data["test_command"]!= "sh fio_test.sh":
            self.data["test_command"]=command

    def get_command_from_log(self):
        with open(self.filename) as fp:
            line=fp.readline()
            return line

    def get_sorted_list_value(self,data):
        ldata=[]
        l=sorted(data.keys())
        tmp1=l.pop(2)
        tmp2=l.pop(6)
        l.insert(1,tmp1)
        l.insert(2,tmp2)
        for key in l:
            ldata.append(data[key])
        return ldata


if __name__ == "__main__":
    mem=fio_base("\/my\/IO_mix55_iod1_thread1_bs.log")
    mem.addRecord("IO_Avg_latency","D33","23")
    mem.addRecord("IO_Lat_Distribution","D33",["22","11","22","33","33","22","22","11","22","33","33","22"])
    mem.updateRecord2DB()
