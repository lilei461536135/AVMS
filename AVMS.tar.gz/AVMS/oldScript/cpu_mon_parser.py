import os,sys,re,json
from collections import defaultdict,Counter

class CPU_mon_parser(object):
    def __init__(self,logpath):
        self.logpath=logpath

    def get_cpu_mon(self,filename="cpu_mon.log"):

        log_test_line = "cat "+os.path.join(self.logpath,filename)+" |grep -v times|grep -v CST"
        logdata = os.popen(log_test_line).readlines()
        #Put value in list
        cpu_dict = defaultdict(list)

        for line in logdata:
            dict_key = line.split('=')[0].strip()
            dict_value = line.split('=')[1].strip()
            #Judge cpu_core
            if  re.match(r'.*_current_freq',dict_key):
                core = re.findall('\d+',dict_key)
                freq_key = '%s_freq'%dict_value
                core_key = 'cpu_core%s'%(core[0])
                cpu_dict.setdefault(freq_key,[]).append(core_key)
            else:
                cpu_dict.setdefault(dict_key,[]).append(dict_value)

        #count
        for key in cpu_dict:
            value = Counter(cpu_dict[key])
            cpu_dict.update({key:value})

        return cpu_dict

if __name__ == "__main__":
    #parser=CPU_mon_parser("/tmp/tools/log/")
    #parser=CPU_mon_parser(sys.argv[1])
    parser=CPU_mon_parser("/var/www/html/result/admin/avmslog/Zhuque_Stress_Test_2016-05-14-14:36:30/10.7.11.82/Stress_linpack")
    data=parser.get_cpu_mon()
    result = json.dumps(data, sort_keys=True, indent=4)
    print '"cpuresult":',result