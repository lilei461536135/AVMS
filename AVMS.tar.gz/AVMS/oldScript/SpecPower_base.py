#!/usr/bin/python
# -*- coding: UTF-8 -*-

from db_baseline_base import db_baseline_base
from graph_base import graph_base

class SpecPower_base(db_baseline_base):
    def __init__(self, user_id,dbname=None):
        self.user_id = user_id
        db_baseline_base.__init__(self, "Power_specpower", self.user_id,dbname)
        self.init_power()
        self.init_CPU_pwr()
        self.init_ssj_ops()
        self.set_test_command()

    def init_power(self):
        if db_baseline_base.getSubMetric(self, "power") == None :
            power_graph = graph_base("specpower power", "x_title", ["idle","load10","load20","load30","load40","load50","load60","load70","load80","load90","load100"], "Spec Power power", "Spec Power", {}, {})
            db_baseline_base.addSubMetric(self, "power", power_graph.data)

    def init_CPU_pwr(self):
        if db_baseline_base.getSubMetric(self, "CPU_pwr") == None:
            CPU_pwr_graph = graph_base("specpower CPU_pwr", "specpower CPU_pwr", ["idle","load10","load20","load30","load40","load50","load60","load70","load80","load90","load100"], "Spec Power CPU_pwr", "Spec Power", {}, {})
            db_baseline_base.addSubMetric(self, "CPU_pwr", CPU_pwr_graph.data)

    def init_ssj_ops(self):
        if db_baseline_base.getSubMetric(self, "ssj_ops") == None :
            ssj_ops_graph = graph_base("specpower ssj_ops", "specpower ssj_ops", ["idle","load10","load20","load30","load40","load50","load60","load70","load80","load90","load100"], "Spec Power ssj_ops", "Spec Power", {}, {})
            db_baseline_base.addSubMetric(self, "ssj_ops", ssj_ops_graph.data)

    def addRecords(self,tcresult,sample):
        self.addRecord("power",sample,self.get_sorted_list_value(tcresult,"SYS_PWR"))
        self.addRecord("CPU_pwr",sample,self.get_sorted_list_value(tcresult,"CPU_PWR"))
        self.addRecord("ssj_ops",sample,self.get_sorted_list_value(tcresult,"ssj_ops"))

    def get_sorted_list_value(self,data,subkey):
        ldata=[]
        l=sorted(data.keys())
        tmp1=l.pop(2)
        l.append(tmp1)
        for key in l:
            ldata.append(data[key][subkey])
        return ldata

    def set_test_command(self, command="python Specpower_auto.py"):
        if self.data["test_command"] == None :
            self.data["test_command"] = command

