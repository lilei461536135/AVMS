import os
import sys
import re
from db_baseline_base import db_baseline_base
from graph_base import graph_base
from pymongo import MongoClient

class mlc_base(db_baseline_base):
    def __init__(self, user_id,dbname=None):
        self.user_id = user_id
        db_baseline_base.__init__(self,"Memory_MLC", self.user_id,dbname)
        self.init_peak_BW_ALL_read()
        self.init_peak_BW_R3_W1()
        self.init_peak_BW_R2_W1()
        self.init_peak_BW_R1_W1()
        self.init_BW_per_socket()
        self.init_idle_latency()
        self.init_Latency_with_Loads()
        self.init_peak_BW_Stream_traid()
        self.set_test_command()



    def init_peak_BW_ALL_read(self):

        if db_baseline_base.getSubMetric(self,"Peak_BW_ALL_Read") == None :
            rate_peek_graph=graph_base("MB/s","Peak_BW_ALL_Read",[],"Memory performance Peak_BW_ALL_Read","Memory Read Bandwith test by MLC",{},{})
            db_baseline_base.addSubMetric(self,"Peak_BW_ALL_Read",rate_peek_graph.data)

    def init_peak_BW_R3_W1(self):
        if db_baseline_base.getSubMetric(self,"Peak_BW_R3_W1") == None :
            rate_peek_graph=graph_base("MB/s","Peak_BW_R3_W1",[],"Memory performance Peak BW 3:1 Read-write","Memory Read/write Bandwith test by MLC",{},{})
            db_baseline_base.addSubMetric(self,"Peak_BW_R3_W1",rate_peek_graph.data)

    def init_peak_BW_R2_W1(self):
        if db_baseline_base.getSubMetric(self,"Peak_BW_R2_W1") == None :
            rate_peek_graph=graph_base("MB/s","Peak_BW_R2_W1",[],"Memory performance Peak BW 2:1 Read-write","Memory Read/write Bandwith test by MLC",{},{})
            db_baseline_base.addSubMetric(self,"Peak_BW_R2_W1",rate_peek_graph.data)

    def init_peak_BW_R1_W1(self):
        if db_baseline_base.getSubMetric(self,"Peak_BW_R1_W1") == None :
            rate_peek_graph=graph_base("MB/s","Peak_BW_R1_W1",[],"Memory performance Peak BW 1:1 Read-write","Memory Read/write Bandwith test by MLC",{},{})
            db_baseline_base.addSubMetric(self,"Peak_BW_R1_W1",rate_peek_graph.data)

    def init_peak_BW_Stream_traid(self):
        if db_baseline_base.getSubMetric(self,"Peak_BW_Stream_traid") == None :
            rate_peek_graph=graph_base("MB/s","Peak_BW_Stream_traid",[],"Memory performance: Peak BW Stream_traid","Memory Read/write Bandwith test by MLC",{},{})
            db_baseline_base.addSubMetric(self,"Peak_BW_Stream_traid",rate_peek_graph.data)

    def init_idle_latency(self):
        if db_baseline_base.getSubMetric(self,"Memory_idle_latency") == None :
            rate_peek_graph=graph_base("ns","Memory_idle_latency",[],"Memory performance:Idle Latency","Memory read latency test by MLC",{},{})
            db_baseline_base.addSubMetric(self,"Memory_idle_latency",rate_peek_graph.data)

    def init_BW_per_socket(self):
        if db_baseline_base.getSubMetric(self,"Memory_BW_Per_Socket") == None :
            rate_peek_graph=graph_base("ns","Memory_BW_Per_Socket",[],"Memory performance: Bandwidth per socket","Memory read Bandwidth test by MLC",{},{})
            db_baseline_base.addSubMetric(self,"Memory_BW_Per_Socket",rate_peek_graph.data)

    def init_Latency_with_Loads(self):
        if db_baseline_base.getSubMetric(self,"Latency_with_Loads") == None :
            rate_peek_graph=graph_base("ns","Latency_with_Loads",[],"Memory performance: Latency with background loads","Memory Latency test by MLC",{},{})
            db_baseline_base.addSubMetric(self,"Latency_with_Loads",rate_peek_graph.data)


    def set_test_command(self,command="./mlc"):
        if self.data["test_command"]== None or self.data["test_command"]!="./mlc":
            self.data["test_command"]=command


    def addRecords(self,tcresut,sample):
        self.addRecord("Peak_BW_ALL_Read",sample,tcresut["memory_Peak_BW"]["ALL Reads"])
        self.addRecord("Peak_BW_R3_W1",sample,tcresut["memory_Peak_BW"]["3:1 Reads-Writes"])
        self.addRecord("Peak_BW_R2_W1",sample,tcresut["memory_Peak_BW"]["2:1 Reads-Writes"])
        self.addRecord("Peak_BW_R1_W1",sample,tcresut["memory_Peak_BW"]["3:1 Reads-Writes"])
        self.addRecord("Peak_BW_Stream_traid",sample,tcresut["memory_Peak_BW"]["Stream-triad like"])
        self.addRecord("Memory_idle_latency",sample,tcresut["Memory_idle_latencies"]["socket0-Memory0"])
        self.addRecord("Memory_BW_Per_Socket",sample,tcresut["Memory_BW_Per_Socket"]["socket0-Memory0"])
        self.addRecord("Latency_with_Loads",sample,tcresut["Latency_with_loads"])





if __name__ == "__main__":
    cpu_fp=SpecCPU_FP_base()
    cpu_fp.updateRecord2DB()
    print cpu_fp.collection.find()[0]
