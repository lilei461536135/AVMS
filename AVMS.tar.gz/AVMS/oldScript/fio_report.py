from db_report_base import db_report_base
import os
import re
from pymongo import MongoClient
import json
from fstack.utils import log as logging

LOG = logging.getLogger(__name__)

class fio_report(db_report_base):

    def __init__(self,number, SN,dev_mode,tags,IP,filename, user_id, category="performance"):
        tcresult=self.parser(filename)
        self.matricname=os.path.basename(filename).split('.')[0]
        db_report_base.__init__(self,number, SN,"IO",dev_mode,tags,self.matricname,tcresult,IP, user_id, category)
        self.insert2reportdb()




    def parser(self,filename):
        with open(filename) as fp:
            #print "parser filename: ",filename
            LOG.info("parser filename: %s", filename)
            tmp = fp.readlines()
            #tmpdata=fp.readlines()[1:]
            tmpdata = tmp[1:]
            #tmpdata=fp.readlines()[0:]
            str=""
            for line in tmpdata:
                str=str+line.rstrip()
            print "filename:", filename
            data=json.loads(str,encoding="utf-8")
            data["cmd"] = tmp[0].strip()
            tmpdic=data["jobs"][0]["read"]["clat"]["percentile"]
            tmpdic1=data["jobs"][0]["trim"]["clat"]["percentile"]
            tmpdic2=data["jobs"][0]["write"]["clat"]["percentile"]
            tmplist=[]
            for key in tmpdic:
                tmplist.append(key)
            for key in tmplist:
                tmpkey=key.replace('.','_')
                tmpdic[tmpkey]=tmpdic[key]
                del tmpdic[key]
            tmplist=[]
            for key1 in tmpdic1:
                tmplist.append(key1)
            for key in tmplist:
                tmpkey1=key.replace('.','_')
                tmpdic1[tmpkey1]=tmpdic1[key]
                del tmpdic1[key]
            tmplist=[]
            for key2 in tmpdic2:
                tmplist.append(key2)
            for key in tmplist:
                tmpkey2=key.replace('.','_')
                tmpdic2[tmpkey2]=tmpdic2[key]
                del tmpdic2[key]
            #print(data)
            LOG.debug(data)
        return data




if __name__ == "__main__":
    #tmp='{"fio version" : "fio-2.0000000","70>=0000":20}'
    #tmp1='{"aaaa":"bbbb","aaa":1111}'
    #data=json.loads(tmp,encoding="utf-8")
    cpu=fio_report("numberfio33","SN2fio33","N31_fio","N31-xxxs-fio","baselinefio","192.168.1.1","/Users/maxuhua/Desktop/IO_read_iod1_thread1_bs512.log")
    #cpu.coll.insert_one(data)
    cpu.insert2reportdb()
