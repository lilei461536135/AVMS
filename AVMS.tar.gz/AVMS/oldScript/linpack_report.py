from db_report_base import db_report_base
import os
import re
from pymongo import MongoClient
import json
from fstack.utils import log as logging
from cpu_mon_parser import CPU_mon_parser

LOG = logging.getLogger(__name__)


class stress_linpack_report(db_report_base):
    def __init__(self,number, SN,dev_mode,tags,IP,filename, user_id):
        tcresult = self.parser(filename)
        db_report_base.__init__(self, number, SN, "CPU", dev_mode, tags, "stress_linpack", tcresult, IP, user_id, "stress")
        db_report_base.insert2reportdb(self)



    def parser(self,filename):
        parser = CPU_mon_parser(filename)
        data=parser.get_cpu_mon()
        result = json.dumps(data, sort_keys=True, indent=4)
        return result