#!/usr/bin/env python2.7
# -*- coding:utf-8 -*-

import os,time
import subprocess
import re
import hashlib

def sub_dict(form_dict, sub_keys, default=None):
    return dict([(k, form_dict.get(k.strip(), default)) for k in sub_keys.split(',')])


def read_cpuinfo():
    p = os.popen('dmidecode -t processor').read()
    socket_num = int(os.popen('dmidecode -t processor | grep "Socket " | wc -l').read())
    line_bool = False
    x = []
    for line in p.splitlines():
        if line.startswith('\tSocket Designation:'):
            line_bool =  True
        if line.startswith('\tFlags:'):
            line_bool = False
        if line.startswith('\tVersion:'):
            line_bool = True
        if line.startswith('\tCharacteristics'):
            line_bool = False
        if line_bool:
            x.append(line.split('\t')[1])
    return x

def get_cpuinfo(data):
    cpu_info = {}
    socket_num = int(os.popen('dmidecode -t processor | grep "Socket " | wc -l').read())
    d = 0
    n = 0
    while d < socket_num:
        socket_slot = 'socket_%s' %d
        socket_loc = {}
        socket_single = data[n:n+22]
        d += 1
        n += 22
        for i in socket_single:
            k,v = [x.strip() for x in i.split(':')]
            socket_loc[k] = v
            cpu_info[socket_slot] = socket_loc
    return cpu_info

def get_meminfo():
    mem_info = {}
    with open('/proc/meminfo', 'r') as f:
        data = f.readlines()
        for i in data:
            k, v = [x.strip() for x in i.split(':')]
            mem_info[k] = str(int(v.split()[0])/1024/1024) + "G"
        
        mem_detail = os.popen('dmidecode -t memory').read().split('\n\n')
        mem_short = mem_detail[1].split('\n\t')
        
        i=1
        while i < len(mem_short):
            #i += 1
            for d in mem_short[1:] :
                k, v = [x.strip() for x in d.split(':')]
                mem_info[k] = v
                i += 1
    return sub_dict(mem_info, 'MemTotal,SwapTotal,MemFree,Buffers,Error Correction Type,Maximum Capacity,Number Of Devices')

def get_memlocation():
    mem_location = {}
    mem_detail = os.popen('dmidecode -t memory | grep -A 18 "Memory Device"').read().split('\n--')
    dimm_num = int(os.popen("dmidecode -t memory | grep 'Part Number' | wc -l").read())
    i=0
    mem_info = {}

    while i < dimm_num:
        mem_single = mem_detail[i].split('\n\t')[1:]
        mem_slot_num = 'mem_slot_%s' %i
        mem_location[mem_slot_num] = mem_info
        mem_info = {}
        i += 1
        for d in mem_single:
            k, v = [x.strip() for x in d.split(':')]
            mem_info[k] = v
            mem_location[mem_slot_num] = mem_info
    return mem_location

def check_raid():
    id = bool(os.popen("package/MegaCli/MegaCli64  -LDInfo -Lall -aALL | grep 'RAID Level'").read())
    if id:
        return "RAID"
    else:
        return "SAS"

def get_storageinfo():
    #check_raid()
    if check_raid() == "RAID" :
        #RAID info
        RAID_INFO = os.popen("package/MegaCli/MegaCli64  -LDInfo -Lall -aALL|grep -E 'RAID Level|Size|Number Of Drives'").read().split("\n")[:-1]
        RAID_NUM = int(os.popen("package/MegaCli/MegaCli64 -LDInfo -Lall -aALL | grep -w 'Virtual Drive:' | wc -l").read().split("\n")[0])
        i = 0
        n = 0
        raid_info={}
        raid_loc={}
        while i < RAID_NUM :
            raid_slot_num = 'raid_A%s' %i
            raid_info[raid_slot_num] = raid_loc
            raid_single = RAID_INFO[n:n+4]
            i += 1
            n += 5
            for d in raid_single:
                k, v = [x.strip() for x in d.split(':')]
                raid_loc[k] = v

        #DISK info
        disk_detail = os.popen("package/MegaCli/MegaCli64 -PDList -aALL | grep -E 'Slot Number:|WWN:|Raw Size:|Device Firmware Level:|Inquiry Data:|Device Speed:|Link Speed:|Media Type:'").read().split("\n")[:-1]
        #disk_detail = os.popen("package/MegaCli/MegaCli64 -PDList -aALL | grep -E 'Slot Number:|WWN:|Raw Size:|Device Firmware Level:|Inquiry Data:|Device Speed:|Link Speed:|Media Type:|Linkspeed:'").read().split("\n")[:-1]
        disk_num = int(os.popen("package/MegaCli/MegaCli64 -PDList -aALL | grep -E 'Slot Number:' | wc -l").read().split("\n")[0])
        j = 0
        m = 0
        disk_info = {}
        #disk_loc = {}
        while j < disk_num:
            disk_slot = 'disk_%s' %j
            disk_single = disk_detail[m:m+8]
            #print disk_single
            #print m
            disk_loc = {}
            j += 1
            m += 8
            for d in disk_single:
                k, v = [x.strip() for x in d.split(':')]
                disk_loc[k] = v
                disk_info[disk_slot] = disk_loc

        #RAID_CARD INFO
        raid_card_info = {}
        card_info = os.popen("package/MegaCli/MegaCli64 -AdpAllInfo -aALL | grep -B 21 'BOOT Version' | grep -E 'Preboot CLI Version|FW Package Build:|BIOS Version|WebBIOS Version|FW Version|NVDATA Version|Boot Block Version|BOOT Version'").read().split("\n")[:-1]
        for d in card_info:
            k, v = [x.strip() for x in d.split(':',1)]
            raid_card_info[k] = v

        #print "RAID card"
        storage_info = {}
        storage_info["raid_info"] = raid_info
        storage_info["disk_info"] = disk_info
        storage_info["raid_card_info"] = raid_card_info
        return storage_info

    elif check_raid() == "SAS" :
        #disk_info
        disk_info = {}
        disk = os.popen("lsscsi|grep '/dev'|awk '{print $NF}'").read().split("\n")[:-1]
        for flag in disk :
            p = os.popen("smartctl -i  %s" %flag).read()[:-1]
            line_in = 0
            disk_slot = {}
            for line in p.splitlines():
                #disk_slot = {}
                if line.startswith('Model Family:'):
                    line_in = 1
                    continue
                if line.startswith('Device Model:'):
                    line_in = 1
                    continue
                if line_in:
                    k, v = [i.strip() for i in line.split(':',1)]
                    disk_slot[k] = v
                    disk_info["%s" %flag] = disk_slot
                else:
                    line_in = 0

        #sas_card_info
        sas_card_info = {}
        card_info = os.popen("sas2ircu 0 display | grep -E 'Controller type|BIOS version|Firmware version'").read().split("\n")[:-1]
        for d in card_info:
            k, v = [x.strip() for x in d.split(':')]
            sas_card_info[k] = v

        storage_info = {}
        storage_info["disk_info"] = disk_info
        storage_info["sas_card_info"] = sas_card_info
        #print storage_info
        return storage_info
        #print "SAS"
    else:
        print "Error: GET DISK INFO FAIDED"

def read_dmidecode():
    p = subprocess.Popen('dmidecode -t 1', stdout=subprocess.PIPE, shell=True)
    return p.communicate()[0]

def get_dmiinfo(data):
    dmi_info = {}
    line_in = False
    for line in data.splitlines():
        if line.startswith('System Information'):
            line_in = True
            continue
        if line.startswith('\t') and line_in:
            k, v = [i.strip() for i in line.split(':')]
            dmi_info[k] = v
        else:
            line_in = False
    return sub_dict(dmi_info, 'Manufacturer,Product Name,Serial Number,')

def read_biosinfo():
    p = subprocess.Popen('dmidecode -t bios | grep -E "Vendor:|Version:|Release Date:"', stdout=subprocess.PIPE, shell=True)
    return p.communicate()[0]

def get_biosinfo(data):
    bios_info = {}
    for line in data.splitlines():
        if line.startswith('\t'):
            k, v = [i.strip() for i in line.split(':')]
            bios_info[k] = v
        else:
            continue
    return sub_dict(bios_info,'Vendor,Version,Release Date')

def read_mcinfo():
    p = subprocess.Popen('ipmitool mc info | grep "Firmware Revision"', stdout=subprocess.PIPE, shell=True)
    return p.communicate()[0]
def get_mcinfo(data):
    mc_info = {}
    for line in data.splitlines():
        #if line.startswith('\t'):
            k, v = [i.strip() for i in line.split(':')]
            mc_info[k] = v
        #else:
        #    continue
    return sub_dict(mc_info,'Firmware Revision')

def get_fruinfo():
    p = os.popen("ipmitool fru").read().split("\n\n")[0]
    fru_info = {}
    line_in = 0 
    for line in p.splitlines():
        #print line
        #print type(line)
        k, v = [i.strip() for i in line.split(':',1)]
        fru_info[k] = v 
    return fru_info


#def read_fruinfo():
    #p = subprocess.Popen('ipmitool fru | grep -E "Chassis Type|Chassis Part Number|Product Serial|Product Manufacturer|Chassis Extra|Product Part Number|"', stdout=subprocess.PIPE, shell=True)
#    p = subprocess.Popen('ipmitool fru',stdout=subprocess.PIPE, shell=True)
#    return p.communicate()[0].split("\n\n")[0]

#def get_fruinfo(data):
    #p = os.popen("ipmitool fru").read().split("\n\n")[0]
    #line_in = 0
#    fru_info = {}
    #for line in p.splitlines():
    #    if line.startswith("FRU Device Description"):
    #        print line
    #        line_in = 1
    #    if line.startswith(" "):
            #print line
    #        line_in = 1
        #if line.startswith(""):
            #print "aaa"
            #print line
        #    line_in = 0
    #    if line_in:
            #print line
     #       k, v = [i.strip() for i in line.split(':',1)]
     #       fru_info[k] = v
        #else:
        #    line_in = 0
#    for d in data:
#        k, v = [i.strip() for i in d.split(':',1)]
#        fru_info[k] = v
#    return fru_info
#print get_fruinfo(read_fruinfo())

def read_ifconfig():
    p = subprocess.Popen('ifconfig', stdout=subprocess.PIPE, shell=True)
    return p.communicate()[0]

def get_ipinfo(data):
    data = (i for i in data.split('\n\n') if i and not i.startswith('lo'))
    ip_info = []
    ifname = re.compile(r'(eth[\d:]*|wlan[\d:]*)')
    ipaddr = re.compile(r'(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})){3}')
    macaddr = re.compile(r'[A-F0-9a-f:]{17}')
    for i in data:
        x = {}
        if ifname.match(i):
            device = ifname.match(i).group()
            x['Adapter'] = device
        if macaddr.search(i):
            mac = macaddr.search(i).group()
            x['MAC'] = mac
        if ipaddr.search(i):
            ip = ipaddr.search(i).group()
            x['IP'] = ip
        else:
            x['IP'] = None
        ip_info.append(x)
    return ip_info

def get_osinfo():
    os_info = {}
    i = os.uname()
    os_info['os_type'] = i[0]
    os_info['node_name'] = i[1]
    os_info['kernel'] = i[2]
    return os_info

def get_indentity(data):
    match_serial = re.compile(r"Serial Number: .*", re.DOTALL)
    match_uuid = re.compile(r"UUID: .*", re.DOTALL)
    if match_serial.search(data):
        serial = match_serial.search(data).group()
    if match_uuid.search(data):
        uuid = match_uuid.search(data).group()
    if serial:
        serial_md5 = hashlib.md5(serial).hexdigest()
        return serial_md5
    elif uuid:
        uuid_md5 = hashlib.md5(uuid).hexdigest()
        return uuid_md5

def info(i):
    if i == 'cpu':
        result = get_cpuinfo(read_cpuinfo())
    elif i == 'mem':
        result = get_meminfo()
    elif i == 'storage':
        result = get_storageinfo()
    elif i == 'memlocation':
        result = get_memlocation()
    elif i == 'ip':
        result = get_ipinfo(read_ifconfig())
    elif i == 'fru':
        result =  get_fruinfo()
    elif i == 'dmi':
        result = get_dmiinfo(read_dmidecode())
    elif i == 'bios':
        result = get_biosinfo(read_biosinfo())
    elif i == 'bmc':
        result = get_mcinfo(read_mcinfo())
    elif i == 'os':
        result = get_osinfo()
    elif i == 'identity':
        result = get_indentity(read_dmidecode())
    else:
        print "Info Error"
    return result

if __name__ == "__main__":
    #ipinfo = get_ipinfo(read_ifconfig())
    #dmiinfo = get_dmiinfo(read_dmidecode())
    #cpuinfo = get_cpuinfo(read_cpuinfo())
    #diskinfo = get_diskinfo(read_fdisk())
    #meminfo = get_meminfo()
    #memloc = get_memlocation()
    osinfo = get_osinfo()
    #identity = get_indentity(read_dmidecode())
#get_storageinfo()
