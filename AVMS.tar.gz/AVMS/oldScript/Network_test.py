#!/usr/bin/env python2.7
# -*- coding:utf-8 -*-

import os,time
import subprocess
import re
import hashlib
import commands
import time

def run(server="client",*para):
	testmod=None
	ip=None
		
	servercmd="qperf &"
	#clientpara=" -vv -oo msg_size:1:64K:*2 "
	clientpara=" -vv -oo msg_size:1:64K:*2 -t 30 "
	retry=0
	if server=="server":
		cmdrt=os.popen(servercmd)
		print "launch qperf server"
	else:
		if len(para)<2:
			print "Error:input para less than 2"
			return -1	
		ip=para[1]
		testmod=para[0]
		filename="Net_qperf_"+testmod+"_by_message_size_"
		timestr=time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
		clientcmd="qperf "+ip+clientpara+testmod+" > "+filename+timestr
		print clientcmd
	 	(cmdRt, sn) = commands.getstatusoutput(clientcmd)	
		print cmdRt ,sn
		while cmdRt != 0 and retry < 30 :
			retry=retry+1
			time.sleep(60)
			(cmdRt, sn) = commands.getstatusoutput(clientcmd)
			print "qperf server is not launch, sleep 1min and retry: ",retry
		print "launch client success"



if __name__ == "__main__":

	#run("server")
	run("servr","tcp_bw","10.218.168.42")
