from hashlib import md5
import os


def getMD5ForBigFile(file):
    m = md5()
    with open(file, "rb") as f :
        buffer = 8192
        while 1:
            chunk = f.read(buffer)
            if not chunk:
                break
            m.update(chunk)
        f.close()
        return m.hexdigest()

def getVersionForName(name):
    name_s = name.split('-')
    if len(name_s) == 1:
        return "Ali-1.0.0"
    name_spot = name_s[1].split('.')
    version = []
    for v in name_spot:
        if v.isdigit():
            version.append(v)
            version.append('.')
        elif v == '.' :
            continue
        else :
            if len(version) > 1 and version[-1] == '.':
                del version[-1]
            break
    return ''.join(version)



def getDictMD5ForTools(path):
    listdir = os.listdir(path)
    last_dict = dict()
    for dir in listdir:
        if os.path.isdir(path + "/" + dir):
            last_dict[dir] = dict()
            child_listdir = os.listdir(path + '/' + dir)
            for child_item in child_listdir:
                if os.path.isfile(path + '/' + dir + '/' + child_item) :
                    last_dict[dir][child_item] = dict()
                    item_md5 = getMD5ForBigFile(path + '/' + dir + '/' + child_item)
                    last_dict[dir][child_item]["md5"] = item_md5
                    last_dict[dir][child_item]["filename"] = child_item
                    last_dict[dir][child_item]["version"] = getVersionForName(child_item)
    return last_dict


if __name__ == "__main__":
    #print getMD5ForBigFile('/tmp/alipayaccount.log')
    print getDictMD5ForTools("/home/shaolong.psl/tools")