#!/usr/bin/python
# -*- coding: UTF-8 -*-

from db_report_base import db_report_base

class SpecPower_report(db_report_base):
    def __init__(self, number, SN, dev_mode, tags, IP, filename, user_id):
        tcresult = self.parser(filename)
        db_report_base.__init__(self, number, SN, "Power", dev_mode, tags, "Power_SpecPower", tcresult, IP, user_id, "performance")
        db_report_base.insert2reportdb(self)


    def parser(self, filename):
        print 'SpecPower parser function.'
        tcresult = dict()
        tcresult["load100"] = dict()
        tcresult["load90"] = dict()
        tcresult["load80"] = dict()
        tcresult["load70"] = dict()
        tcresult["load60"] = dict()
        tcresult["load50"] = dict()
        tcresult["load40"] = dict()
        tcresult["load30"] = dict()
        tcresult["load20"] = dict()
        tcresult["load10"] = dict()
        tcresult["idle"] = dict()
        listArr = ["CPU_UTIL", "SYS_PWR", "CPU_PWR", "MEM_PWR", "ssj_ops"]
        list_first_arr = ["load100", "load90", "load80", "load70", "load60", "load50", "load40", "load30", "load20", "load10", "idle"];
        with open(filename) as fp :
            for i in range(100):
                #print i
                line = fp.readline()
                if i < 7 or i > 17 :
                    continue
                #print line
                lineArr = line.strip().split('|')
                #print lineArr
                for p in range(1, 6):
                    #print lineArr[p]
                    tcresult[list_first_arr[i-7]][listArr[p-1]] = lineArr[p].strip()
            #print tcresult

        return tcresult



if __name__ == "__main__":
    specpower = parserSpecPower("1111", "2222", "3333", "4444", "5555", "6666", "7777", "power_20151217094647_NGIS-1A420WJ00X254800L")


